import optax
from attr import define, field
from jax import jit, vmap, value_and_grad, device_put
import jax.numpy as jnp
from phisolve.refiners.refiner import Refiner, prepare_refiner_problem
from phisolve.problems import BoxQP, LCQP, QUBO
import scipy as sp
import jax.experimental.sparse as jsp
from phisolve.utils.jax_utils import sp_sparse_mat_to_jsp_BCSR, spcomp_matvec
from phisolve.utils.device_utils import resolve_device
from phisolve.utils.precision import (
    average_prepared_quadratic_blocks, prepare_jax_coefficient,
    promote_prepared_quadratic,
)
from functools import partial
import jax


@define
class JaxAdam(Refiner):
    """Adam refinement for continuous, bounds-only quadratic programs.

    Gradients use the symmetric part of Q, as required by 0.5 * x.T @ Q @ x.
    """

    learning_rate: float = field(default=1e-1)
    iterations: int = field(default=300)
    device: str = field(default="cpu")
    vmappable: bool = field(default=True)

    def validate_problem(self, problem):
        if isinstance(problem, QUBO) or getattr(problem, "n_binary_vars", 0) > 0:
            raise ValueError(
                "JaxAdam requires continuous variables; fix binary values first."
            )
        if not isinstance(problem, BoxQP):
            raise TypeError("JaxAdam requires a continuous box-constrained QP.")
        # Array shapes are static under jit/vmap. Do not inspect traced values.
        if isinstance(problem, LCQP) and (
            problem.A.shape[0] > 0 or problem.C.shape[0] > 0
        ):
            raise ValueError(
                "JaxAdam does not support linear constraints; use a constrained "
                "refiner such as ScipyMinimize."
            )
        resolve_device(self.device)

    def run_jax(self, samples):
        optimizer = optax.adam(self.learning_rate)

        samples = device_put(samples, resolve_device(self.device))
        opt_state = optimizer.init(samples)

        Q, w = self.problem.Q, self.problem.w
        # Promote before transposition/halving so narrow JAX coefficients and
        # wider captured arrays retain their Hessian until skew terms cancel.
        Q = promote_prepared_quadratic(Q)
        Q = average_prepared_quadratic_blocks(Q, Q.T)

        def grad_gen(Q, x):
            return spcomp_matvec(Q, x) + w
        if sp.sparse.issparse(Q):
            Q = sp_sparse_mat_to_jsp_BCSR(Q)
        grad = partial(grad_gen, Q)
        
        def step(samples, opt_state):
            # loss_values, grads = vmap(value_and_grad(self.problem.obj))(samples)
            grads = vmap(grad)(samples)
            updates, opt_state = optimizer.update(grads, opt_state, samples)
            samples = vmap(optax.apply_updates)(samples, updates)
            samples = jnp.minimum(jnp.maximum(samples, self.problem.bounds[0]), self.problem.bounds[1])
            return samples, opt_state

        for _ in range(self.iterations):
            samples, opt_state = jit(step)(samples, opt_state)
        return samples

    def refine(self, samples, problem):
        self.validate_problem(problem)
        self.problem = prepare_refiner_problem(
            problem, jax_fields={"Q", "w", "A", "b", "C", "d", "bounds"}, preserve_jax=True
        )
        dtype = jnp.float64 if jax.config.x64_enabled else jnp.float32
        samples = jnp.asarray(prepare_jax_coefficient(samples, "initial samples"), dtype=dtype)
        processed_samples = self.run_jax(samples)
        return processed_samples
