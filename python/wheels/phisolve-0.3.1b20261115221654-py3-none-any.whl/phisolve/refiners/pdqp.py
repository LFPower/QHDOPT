from attr import define, field
from jax import jit, vmap, devices, lax
import jax
import numpy as np
from phisolve.problems.lcqp import LCQP
from phisolve.problems.boxqp import BoxQP
from phisolve.problems.qubo import QUBO
import jax.numpy as jnp
from phisolve.refiners.refiner import Refiner, prepare_refiner_problem
from phisolve.utils.jax_utils import jax_device
from phisolve.utils.device_utils import resolve_device
from phisolve.utils.precision import prepare_jax_coefficient
import mpax as mp


class _ZeroNormSafeRaPDHG(mp.raPDHG):
    """Keep MPAX's step initialization finite for exactly zero operators.

    MPAX 0.2.4's power iteration divides by zero for an empty or all-zero
    matrix. Its result is used only after initialization, so replace these
    known zero norms before taking a step. Nonzero operators retain MPAX's
    estimates and step rules. No model rows, including constant rows, change.
    """

    def initialize_solver_status(
        self, scaled_problem, initial_primal_solution, initial_dual_solution,
        is_lp=True,
    ):
        qp = scaled_problem.scaled_qp
        data = qp.constraint_matrix.data
        adaptive = self.adaptive_step_size
        # The adaptive LP initializer reduces max(data) without an identity;
        # use the constant initializer when there are no stored entries, then
        # restore the LP's adaptive rule with a finite initial step below.
        if adaptive and data.size == 0:
            self.adaptive_step_size = False
        state, restart = super().initialize_solver_status(
            scaled_problem, initial_primal_solution, initial_dual_solution, is_lp
        )
        if not self.adaptive_step_size:
            self._norm_A = jnp.where(jnp.any(data != 0), self._norm_A, 0.0)
            self._norm_Q = jnp.where(
                jnp.any(qp.objective_matrix.data != 0), self._norm_Q, 0.0
            )
        self.adaptive_step_size = adaptive
        if adaptive:
            state.step_size = jnp.where(jnp.any(data != 0), state.step_size, 1.0)
        return state, restart

    def calculate_constant_step_size(self, primal_weight, iteration, last_step_size):
        step = super().calculate_constant_step_size(
            primal_weight, iteration, last_step_size
        )
        # A zero Hessian and zero constraint operator have no curvature-based
        # step restriction. Retain the finite initial/previous step, rather
        # than allowing an infinite step to produce inf * 0 or inf / inf.
        return jnp.where(
            (self._norm_A == 0) & (self._norm_Q == 0), last_step_size, step
        )


@define
class PDQP(Refiner):
    """Continuous QP refinement using the objective's symmetric Hessian."""

    iterations: int = field(default=1000)
    max_K: int = field(default=1)
    device: str = field(default="cpu")
    vmappable: bool = field(default=True)

    def validate_problem(self, problem):
        if isinstance(problem, QUBO) or getattr(problem, "n_binary_vars", 0) > 0:
            raise ValueError(
                "PDQP requires continuous variables; fix binary values first."
            )
        if not isinstance(problem, BoxQP):
            raise TypeError("PDQP requires a continuous quadratic program.")
        resolve_device(self.device)
    
    def pdqp_main(self, samples, dual_vars = None):
        # The skew part of Q contributes zero to 0.5 * x.T @ Q @ x.
        # Keep checked host coefficients in float64 until that part cancels;
        # narrowing first can overflow or erase a representable Hessian entry.
        # Promote lower-precision JAX values before arithmetic, but never narrow
        # Q before symmetrization. Half-scaling avoids addition overflow.
        dtype = jnp.float64 if jax.config.x64_enabled else jnp.float32
        Q = self.problem.Q
        if (isinstance(Q, jax.Array) and not isinstance(Q, jax.core.Tracer)
                and Q.dtype.itemsize > jnp.dtype(dtype).itemsize):
            # A concrete array can outlive the x64 context that created it.
            # JAX arithmetic would narrow it implicitly; retain its represented
            # values on the host until cancellation, without changing config.
            Q = np.asarray(Q)
        if Q.dtype.itemsize < jnp.dtype(dtype).itemsize:
            Q = Q.astype(dtype)
        Q = (0.5 * Q + 0.5 * Q.T).astype(dtype)
        qp = mp.create_qp(Q,
                          self.problem.w, 
                          self.problem.C, 
                          self.problem.d, 
                          - self.problem.A, 
                          - self.problem.b,
                          self.problem.bounds[0],
                          self.problem.bounds[1])

        # Concatenation can put an equality block's padding into a valid row
        # with an out-of-range column. Canonicalize before MPAX converts to CSR,
        # so its matvec cannot read those padding columns. Fixed nse keeps JIT
        # shapes static, and both orientations must use the repaired indices.
        qp.constraint_matrix = qp.constraint_matrix.sum_duplicates(
            nse=qp.constraint_matrix.nse, remove_zeros=False
        )
        qp.constraint_matrix_t = qp.constraint_matrix.T

        solver = _ZeroNormSafeRaPDHG(eps_abs=1e-4,
                           eps_rel=1e-4, 
                           warm_start=True, 
                           iteration_limit=self.iterations*self.max_K,
                           display_frequency=1,
                           verbose=False)

        def solve_qp_with_dual(x, y, z):
            result = solver.optimize(qp, x, jnp.concatenate((z, y)))
            return result.primal_solution

        if dual_vars is None:
            dual_vars = (jnp.zeros((samples.shape[0], self.problem.A.shape[0]), dtype=samples.dtype),
                         jnp.zeros((samples.shape[0], self.problem.C.shape[0]), dtype=samples.dtype))
        
        res = jax.vmap(solve_qp_with_dual)(samples, dual_vars[0], dual_vars[1])

        res = jax.device_get(res)
        return res

    def refine(self, samples, problem, dual_vars = None):
        self.validate_problem(problem)
        problem = prepare_refiner_problem(
            problem, jax_fields={"Q", "w", "A", "b", "C", "d", "bounds"}, preserve_jax=True
        )
        if isinstance(problem, LCQP):
            self.problem = problem
        elif isinstance(problem, BoxQP):
            self.problem = LCQP(Q=problem.Q, w=problem.w, bounds=problem.bounds)
        else:
            raise ValueError("problem is not in {BoxQP, LCQP}.")

        # MPAX's sparse concatenation requires matching dtypes, including
        # empty constraint blocks. Normalize only after integer precision has
        # been checked, and keep sparse operands sparse and JAX values traceable.
        # Q retains its prepared precision until pdqp_main forms the Hessian.
        dtype = jnp.float64 if jax.config.x64_enabled else jnp.float32
        for name in ("w", "A", "b", "C", "d"):
            setattr(self.problem, name, getattr(self.problem, name).astype(dtype))
        self.problem.bounds = tuple(bound.astype(dtype) for bound in self.problem.bounds)

        target = resolve_device(self.device)
        with jax.default_device(target):
            samples = jax.device_put(
                jnp.asarray(prepare_jax_coefficient(samples, "initial samples"), dtype=dtype), target
            )
            if dual_vars is not None:
                dual_vars = tuple(
                    jnp.asarray(prepare_jax_coefficient(value, "initial dual variables"), dtype=dtype)
                    for value in dual_vars
                )
                dual_vars = jax.device_put(dual_vars, target)
            processed_samples = jit(self.pdqp_main)(samples, dual_vars)
        return processed_samples
