from attr import define, field
from jax import device_put, jit, grad, jacfwd, jacrev
from jax.sharding import SingleDeviceSharding
import jax.numpy as jnp
from scipy.optimize import Bounds
from cyipopt import minimize_ipopt
from phisolve.refiners.refiner import Refiner, prepare_refiner_problem
from phisolve.utils.device_utils import resolve_device
from phisolve.utils.precision import (
    average_prepared_quadratic_blocks, prepare_jax_coefficient,
    promote_prepared_quadratic,
)
from phisolve.problems.boxqp import BoxQP
from phisolve.problems.lcqp import LCQP
from phisolve.problems.qubo import QUBO


@define
class IpoptMinimize(Refiner):
    """Continuous bounds-only refinement; linear constraints are unsupported."""

    tol: float = field(default=1e-6)
    max_iter: float = field(default=100)
    device: str = field(default="cpu")

    def validate_problem(self, problem):
        if isinstance(problem, QUBO) or getattr(problem, "n_binary_vars", 0) > 0:
            raise ValueError(
                "IpoptMinimize requires continuous variables; fix binary values first."
            )
        if not isinstance(problem, BoxQP):
            raise TypeError("IpoptMinimize requires a continuous box-constrained QP.")
        if isinstance(problem, LCQP) and (
            problem.A.shape[0] > 0 or problem.C.shape[0] > 0
        ):
            raise ValueError(
                "IpoptMinimize does not support linear constraints; use a "
                "constrained refiner such as ScipyMinimize."
            )
        resolve_device(self.device)

    def refine(self, samples, problem):
        self.validate_problem(problem)
        self.problem = prepare_refiner_problem(
            problem, jax_fields={"Q", "w", "bounds"}
        )
        # Preserve original integer checks and remove the skew part before
        # constructing objective, gradient and Hessian callbacks in JAX.
        Q = promote_prepared_quadratic(self.problem.Q)
        self.problem.Q = average_prepared_quadratic_blocks(Q, Q.T)
        self.problem = self.problem.to_dense()
        refined_samples = []
        device = resolve_device(self.device)
        # Constant callbacks can lose their input during compilation, so pin
        # their outputs as well as placing each optimizer-supplied argument.
        sharding = SingleDeviceSharding(device)
        obj_jit = jit(self.problem.obj, out_shardings=sharding)
        grad_jit = jit(grad(obj_jit), out_shardings=sharding)
        hess_jit = jit(jacrev(jacfwd(obj_jit)), out_shardings=sharding)

        # IPOPT supplies fresh host arrays during optimization. Place each
        # callback input explicitly instead of using deprecated jit options.
        def eval_obj(x):
            return obj_jit(device_put(x, device))

        def eval_grad(x):
            return grad_jit(device_put(x, device))

        def eval_hess(x):
            return hess_jit(device_put(x, device))
        
        lower_bound = jnp.array(self.problem.bounds[0])
        upper_bound = jnp.array(self.problem.bounds[1])
        bounds = Bounds(lower_bound, upper_bound)
        constraints = ()

        for k in range(len(samples)):
            if samples[k] is None:
                refined_samples.append(None)
                continue
            result = minimize_ipopt(
                eval_obj,
                prepare_jax_coefficient(samples[k], "initial candidate"),
                jac=eval_grad,
                hess=eval_hess,
                bounds=bounds,
                constraints=constraints,
                options={"tol": self.tol, "max_iter": self.max_iter},
            )
            refined_samples.append(result.x)
        
        return refined_samples

