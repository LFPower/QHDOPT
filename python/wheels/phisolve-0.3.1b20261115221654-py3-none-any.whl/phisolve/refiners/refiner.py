import abc
from abc import ABC
import jax

from attr import define, field

from phisolve.problems import Problem
from phisolve.utils.precision import prepare_float64_coefficient, prepare_jax_coefficient


def prepare_refiner_problem(problem, *, jax_fields, preserve_jax=False):
    """Normalize model operands before solver arithmetic without source writes.

    Integer execution checks apply only to fields entering JAX. Other fields,
    such as SciPy's constraints and bounds, retain host float64 precision.
    """
    def prepare(value, name):
        if name in jax_fields:
            value = prepare_jax_coefficient(value, name)
            if preserve_jax or not isinstance(value, (jax.Array, jax.core.Tracer)):
                return value
        return prepare_float64_coefficient(value, name, preserve_jax=preserve_jax)

    kwargs = problem.to_dict()
    for name in ("Q", "w", "A", "b", "C", "d"):
        if name in kwargs:
            kwargs[name] = prepare(kwargs[name], name)
    kwargs["bounds"] = tuple(prepare(bound, "bounds") for bound in kwargs["bounds"])
    return type(problem)(**kwargs)

@define
class Refiner(ABC):
    iterations: int = field(default=1000)
    device: str = field(default="cpu")
    problem: Problem = field(default=None)
    vmappable: bool = field(default=False)

    def validate_problem(self, problem):
        """Reject unsupported models before refinement or compiled execution.

        Refiners with a restricted problem class override this hook. The
        default preserves compatibility with existing custom refiners.
        """
        return None

    @abc.abstractmethod
    def refine(self, samples, problem):
        pass
