import numpy as np
from attr import define
from attrs import field
from jax import device_put, jit, grad
from scipy.optimize import Bounds, minimize, LinearConstraint
from phisolve.refiners.refiner import Refiner, prepare_refiner_problem
from phisolve.problems import BoxQP, LCQP, QUBO
from phisolve.validation import validate_candidate
from phisolve.utils.device_utils import resolve_device
from phisolve.utils.precision import (
    average_prepared_quadratic_blocks, prepare_jax_coefficient,
    promote_prepared_quadratic,
)


@define
class ScipyMinimize(Refiner):
    """Refine continuous QPs with SciPy.

    With ``method=None``, use SLSQP for linear constraints and TNC for
    bounds-only problems. Explicit methods must support the problem's
    constraints. Caller-provided options are passed through unchanged.

    Returned candidates must pass independent model validation. A feasible
    candidate is retained even when the optimizer has not converged; invalid
    candidates are returned as None. ``last_diagnostics`` records convergence
    status and validation separately for each input candidate.
    """

    method: str = field(default=None)
    options: dict = field(default=None)
    device: str = field(default="cpu")
    last_diagnostics: list = field(factory=list, init=False)

    def validate_problem(self, problem):
        if isinstance(problem, QUBO) or getattr(problem, "n_binary_vars", 0) > 0:
            raise ValueError(
                "ScipyMinimize requires continuous variables; fix binary values first."
            )
        if not isinstance(problem, BoxQP):
            raise TypeError("ScipyMinimize requires a continuous quadratic program.")
        has_constraints = isinstance(problem, LCQP) and (
            problem.A.shape[0] > 0 or problem.C.shape[0] > 0
        )
        if has_constraints and self.method is not None and not callable(self.method):
            if self.method.lower() not in {
                "slsqp", "trust-constr", "cobyla", "cobyqa"
            }:
                raise ValueError(
                    f"Method {self.method!r} does not support linear constraints; "
                    "use method=None, 'SLSQP', or another constrained method."
                )
        resolve_device(self.device)

    def refine(self, samples, problem):
        self.last_diagnostics = []
        self.validate_problem(problem)
        self.problem = prepare_refiner_problem(problem, jax_fields={"Q", "w"})
        # Keep integer checks on the original coefficients, then cancel the
        # skew part in prepared precision before JAX evaluates derivatives.
        Q = promote_prepared_quadratic(self.problem.Q)
        self.problem.Q = average_prepared_quadratic_blocks(Q, Q.T)
        self.problem = self.problem.to_dense()
        refined_samples = []
        device = resolve_device(self.device)
        eval_jit = jit(self.problem.obj)
        eval_grad = jit(grad(eval_jit))

        def scipy_obj(x):
            return float(eval_jit(device_put(x, device)))

        def scipy_grad(x):
            # JAX defaults to float32; SciPy's SLSQP requires float64 arrays.
            return np.asarray(eval_grad(device_put(x, device)), dtype=np.float64)

        lower_bound = np.asarray(self.problem.bounds[0], dtype=np.float64)
        upper_bound = np.asarray(self.problem.bounds[1], dtype=np.float64)
        bounds = Bounds(lower_bound, upper_bound) if problem.nvar else None
        constraints = []
        if isinstance(self.problem, LCQP) and problem.nvar:
            if self.problem.A.shape[0]:
                constraints.append(
                    LinearConstraint(self.problem.A, -np.inf, self.problem.b)
                )
            if self.problem.C.shape[0]:
                constraints.append(
                    LinearConstraint(self.problem.C, self.problem.d, self.problem.d)
                )

        method = self.method
        if method is None:
            method = "SLSQP" if constraints else "TNC"
        options = self.options
        if options is None:
            options = (
                dict(gtol=1e-6, eps=1e-9)
                if isinstance(method, str) and method.lower() == "tnc"
                else {}
            )

        for sample in samples:
            initial_error = None
            try:
                initial = (
                    np.asarray(prepare_jax_coefficient(sample, "initial candidate"), dtype=np.float64)
                    if np.isrealobj(sample)
                    else None
                )
            except (TypeError, ValueError, OverflowError) as error:
                initial = None
                initial_error = str(error)
            if (
                initial is None
                or initial.shape != (problem.nvar,)
                or not np.all(np.isfinite(initial))
            ):
                refined_samples.append(None)
                validation = validate_candidate(problem, sample)
                self.last_diagnostics.append(
                    dict(
                        success=False,
                        status=None,
                        message=f"Invalid initial candidate: {initial_error or validation.reason}.",
                        validation=validation,
                    )
                )
                continue
            if problem.nvar == 0:
                validation = validate_candidate(problem, initial)
                refined_samples.append(initial.copy() if validation.valid else None)
                self.last_diagnostics.append(
                    dict(
                        success=None,
                        status=None,
                        message="No continuous variables to optimize.",
                        validation=validation,
                    )
                )
                continue
            result = minimize(
                scipy_obj,
                initial,
                method=method,
                jac=scipy_grad,
                bounds=bounds,
                constraints=constraints,
                options=options,
            )
            validation = validate_candidate(problem, result.x)
            success = getattr(result, "success", None)
            message = getattr(result, "message", None)
            self.last_diagnostics.append(
                dict(
                    success=None if success is None else bool(success),
                    status=getattr(result, "status", None),
                    message=None if message is None else str(message),
                    validation=validation,
                )
            )
            refined_samples.append(
                np.asarray(result.x, dtype=np.float64).copy()
                if validation.valid
                else None
            )
        return refined_samples

