"""Validated result selection and shot-weighted statistics."""

from dataclasses import dataclass
from numbers import Integral, Real
from typing import Any, List

from attr import define, field
import numpy as np
from phisolve.validation import CandidateValidation, _tolerance, validate_candidate


VALIDATED_SOLUTION = "VALIDATED_SOLUTION"
NO_VALIDATED_SOLUTION = "NO_VALIDATED_SOLUTION"


class NoValidatedSolutionError(ValueError):
    """No positive-count candidate passed original-model validation."""


@dataclass(frozen=True)
class SelectionResult:
    """A validated candidate, or an explicit absence of a validated solution.

    ``source`` is the actual candidate stage: ``coarse`` or ``refined``.
    Refinement diagnostics describe convergence separately from feasibility.
    """

    status: str
    candidate: np.ndarray | None
    objective: float | None
    source: str
    index: int | None
    validation: CandidateValidation | None
    refinement_diagnostics: Any = None


@define
class Response:
    problem_instance = field()
    coarse_samples: List[List[float]] = field()
    sample_counts: np.ndarray = field()
    refined_samples: List[List[float]] = field(default=None)
    time = field(default=None)
    detailed_time = field(default=None)
    refinement_diagnostics = field(default=None)

    def __attrs_post_init__(self):
        self._check_alignment()

    def _check_alignment(self):
        # Preserve Python integers in mixed integer/float sequences before
        # checking them; NumPy's usual promotion can round large shot counts.
        counts = np.asarray(self.sample_counts, dtype=object)
        if counts.ndim != 1 or len(counts) != len(self.coarse_samples):
            raise ValueError("sample_counts must align with coarse_samples")
        for count in counts:
            if isinstance(count, (bool, np.bool_)) or not isinstance(count, Real):
                raise ValueError("sample_counts must contain nonnegative integers")
            if isinstance(count, Integral):
                valid = count >= 0
            else:
                valid = np.isfinite(count) and count >= 0 and count == int(count)
            if not valid:
                raise ValueError("sample_counts must contain nonnegative integers")
        if self.refined_samples is not None and len(self.refined_samples) != len(
            counts
        ):
            raise ValueError("refined_samples must align with sample_counts")
        if self.refinement_diagnostics is not None and len(
            self.refinement_diagnostics
        ) != len(self.samples):
            raise ValueError("refinement_diagnostics must align with final samples")
        return tuple(int(count) for count in counts)

    @property
    def samples(self):
        return (
            self.refined_samples
            if self.refined_samples is not None
            else self.coarse_samples
        )

    def _stage(self, source):
        if source == "coarse":
            return self.coarse_samples, "coarse"
        if source != "final":
            raise ValueError("source must be 'final' or 'coarse'")
        return self.samples, "refined" if self.refined_samples is not None else "coarse"

    def select(self, feasibility_tol=1e-5, source="final"):
        """Select the lowest original objective among valid positive-count rows.

        Invalid candidates remain available in the response as diagnostics;
        they never substitute for a missing validated solution. Ties keep the
        first candidate. The selected candidate is an independent readonly copy.
        """
        tolerance = _tolerance(feasibility_tol, "feasibility_tol")
        counts = self._check_alignment()
        samples, actual_source = self._stage(source)
        best_index = None
        best_validation = None
        for index, (candidate, count) in enumerate(zip(samples, counts)):
            if count == 0:
                continue
            validation = validate_candidate(self.problem_instance, candidate, tolerance)
            if validation.valid and (
                best_validation is None
                or validation.objective < best_validation.objective
            ):
                best_index, best_validation = index, validation
        if best_index is None:
            return SelectionResult(
                NO_VALIDATED_SOLUTION, None, None, actual_source, None, None
            )
        candidate = np.array(samples[best_index], dtype=np.float64, copy=True)
        candidate.setflags(write=False)
        diagnostics = None
        if source == "final" and self.refinement_diagnostics is not None:
            diagnostics = self.refinement_diagnostics[best_index]
        return SelectionResult(
            VALIDATED_SOLUTION,
            candidate,
            best_validation.objective,
            actual_source,
            best_index,
            best_validation,
            diagnostics,
        )

    @staticmethod
    def _require_selection(selection):
        if selection.status != VALIDATED_SOLUTION:
            raise NoValidatedSolutionError(
                f"No validated solution in {selection.source} samples"
            )
        return selection

    def minimum(self, vios_eps=1e-5):
        return self._require_selection(self.select(vios_eps)).objective

    @property
    def minimizer(self):
        return self._require_selection(self.select()).candidate

    @property
    def coarse_min(self):
        return self._require_selection(self.select(source="coarse")).objective

    @property
    def percent_in_subspace(self):
        """Unweighted fraction of present final rows, not a feasibility rate.

        A row is present when it is not ``None``. Empty batches have fraction 0.
        """
        return (
            sum(sample is not None for sample in self.samples) / len(self.samples)
            if len(self.samples)
            else 0.0
        )

    def _success_probability(self, source, tol, feasibility_tol):
        objective_tol = _tolerance(tol, "tol")
        feasibility_tol = _tolerance(feasibility_tol, "feasibility_tol")
        counts = self._check_alignment()
        total = sum(counts)
        if total == 0:
            raise ValueError("success probability requires at least one recorded trial")
        selection = self.select(feasibility_tol=feasibility_tol, source=source)
        if selection.status == NO_VALIDATED_SOLUTION:
            return 0.0
        samples, _ = self._stage(source)
        successes = 0
        for candidate, count in zip(samples, counts):
            if count == 0:
                continue
            validation = validate_candidate(
                self.problem_instance, candidate, feasibility_tol
            )
            if validation.valid and (
                abs(validation.objective - selection.objective) <= objective_tol
            ):
                successes += count
        return successes / total

    def succ_prob(self, tol=1e-3, feasibility_tol=1e-5):
        """Weighted final successes; invalid rows still count as failed trials.

        ``tol`` compares objectives to this stage's best validated objective.
        ``feasibility_tol`` independently controls original-model validation.
        """
        return self._success_probability("final", tol, feasibility_tol)

    def succ_prob_coarse(self, tol=1e-3, feasibility_tol=1e-5):
        """Weighted coarse successes against the best validated coarse objective."""
        return self._success_probability("coarse", tol, feasibility_tol)
