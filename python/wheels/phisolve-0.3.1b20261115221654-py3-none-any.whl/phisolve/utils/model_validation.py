"""Host-side structural checks for the finite-box QIHD formulation."""

from numbers import Integral

import numpy as np
from scipy import sparse

from phisolve.validation import as_float64_exact
from phisolve.utils.precision import prepare_float64_coefficient


def positive_integer(value, name):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, Integral) or value <= 0:
        raise ValueError(f"{name} must be a positive integer")
    return int(value)


def validate_qihd_model(problem):
    """Reject unsupported model shapes/values before affine transformation.

    QIHD's existing force assumes a symmetric quadratic matrix and finite box
    endpoints. Candidate validation is separate and evaluates original models.
    """
    n = positive_integer(problem.nvar, "nvar")
    n_binary = getattr(problem, "n_binary_vars", 0)
    if (isinstance(n_binary, (bool, np.bool_))
            or not isinstance(n_binary, Integral) or not 0 <= n_binary <= n):
        raise ValueError("n_binary_vars must be an integer between 0 and nvar")

    def check(value, shape, name):
        if sparse.issparse(value):
            actual_shape = value.shape
            data = as_float64_exact(value.tocoo().data, name)
        else:
            # Check original wrapper/container leaves before NumPy promotion
            # can erase integer provenance, then inspect the exposed shape.
            data = as_float64_exact(value, name)
            actual_shape = data.shape
        if actual_shape != shape:
            raise ValueError(f"{name} must have shape {shape}, got {actual_shape}")
        if not np.all(np.isfinite(data)):
            raise ValueError(f"{name} must contain finite real values")
        return data

    q_data = check(problem.Q, (n, n), "Q")
    check(problem.w, (n,), "w")
    if sparse.issparse(problem.Q):
        # Input integer arithmetic can overflow during subtraction or abs,
        # even for a symmetric matrix such as int8([[-128]]). Exactness was
        # checked above before making this independent floating working copy.
        q = prepare_float64_coefficient(problem.Q, "Q")
        delta = abs(q - q.T)
        # Match the entrywise dense tolerance, without densifying or hiding
        # a small asymmetric entry behind a large unrelated diagonal.
        excess = (delta - 1e-7 * abs(q.T)).tocoo()
        symmetric = np.max(excess.data, initial=0.0) <= 1e-10
    else:
        symmetric = np.allclose(q_data, q_data.T, rtol=1e-7, atol=1e-10)
    if not symmetric:
        raise ValueError("QIHD requires a symmetric quadratic matrix Q")
    for matrix_name, rhs_name, count_name in (("A", "b", "ncon_ineq"),
                                             ("C", "d", "ncon_eq")):
        matrix = getattr(problem, matrix_name)
        rhs = as_float64_exact(getattr(problem, rhs_name), rhs_name)
        if len(rhs.shape) != 1:
            raise ValueError(f"{rhs_name} must be a vector")
        check(matrix, (rhs.shape[0], n), matrix_name)
        check(rhs, (rhs.shape[0],), rhs_name)
        if getattr(problem, count_name) != rhs.shape[0]:
            raise ValueError(f"{count_name} does not match {matrix_name}")
    lower, upper = problem.bounds
    lower = check(lower, (n,), "lower bounds")
    upper = check(upper, (n,), "upper bounds")
    if np.any(lower > upper):
        raise ValueError("lower bounds must not exceed upper bounds")
