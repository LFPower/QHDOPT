from typing import Callable
from functools import partial
from dataclasses import dataclass

import jax
from jax import jit

from phisolve.utils.device_utils import resolve_device
from phisolve.utils.model_validation import positive_integer


@partial(jit, static_argnames=("time_steps",))
def _integrate_partial(dynamic, initial_state, variables, time_steps):
    """Compile by callable structure, with Partial operands supplied at runtime."""
    def step(state, value):
        return dynamic(state, value), None

    return jax.lax.scan(step, initial_state, variables, length=time_steps)[0]


@dataclass(frozen=True)
class _ReusableDynamics:
    """Explicit marker; the wrapped Partial's operands remain runtime inputs."""

    dynamic: jax.tree_util.Partial

    def __call__(self, *args, **kwargs):
        return self.dynamic(*args, **kwargs)


class Integrator:

    @staticmethod
    def reusable(dynamic: Callable, *operands, **keyword_operands):
        """Opt into scan reuse with a stable pure function and explicit operands.

        Every bound operand is a dynamic JAX input. Static Python control-flow
        or shape choices must instead belong to the stable function, as in
        QIHD's algorithm-mode factory. Changing model values must be operands,
        not closed-over constants. Invalid dynamic inputs raise normally.
        """
        return _ReusableDynamics(
            jax.tree_util.Partial(dynamic, *operands, **keyword_operands)
        )

    @staticmethod
    def integrate(
        dynamic: Callable,
        initial_state,
        time_dependent_variables=None,
        time_steps=None,
        device="cpu",
    ):
        """Integrate over aligned schedule arrays while preserving their pytree.

        Empty schedule pytrees, including None, require explicit time_steps.
        Every array leaf must have the same positive leading length.

        Only an explicit Integrator.reusable callable reuses compilation.
        Ordinary callables and jax.tree_util.Partial retain per-call tracing,
        including bound numeric control-flow or shape metadata. JAX's usual
        closure-capture rules still apply to those ordinary callables.
        """
        target = resolve_device(device)
        initial_state = jax.device_put(initial_state, target)
        if time_steps is not None:
            time_steps = positive_integer(time_steps, "time_steps")

        length = None
        for leaf in jax.tree_util.tree_leaves(time_dependent_variables):
            shape = getattr(leaf, "shape", None)
            if shape is None or len(shape) == 0:
                raise ValueError("schedule leaves must have a leading dimension")
            leaf_length = positive_integer(shape[0], "schedule length")
            if length is None:
                length = leaf_length
            elif leaf_length != length:
                raise ValueError("schedule leaves must have matching leading lengths")

        if length is None:
            if time_steps is None:
                raise ValueError("time_steps is required without schedule array leaves")
        elif time_steps is not None and time_steps != length:
            raise ValueError("time_steps must match the schedule length")
        time_dependent_variables = jax.device_put(time_dependent_variables, target)

        if isinstance(dynamic, _ReusableDynamics):
            prepared_dynamic = jax.device_put(dynamic.dynamic, target)
            with jax.default_device(target):
                return _integrate_partial(
                    prepared_dynamic, initial_state, time_dependent_variables,
                    time_steps,
                )

        def new_dynamic(state, variables):
            return dynamic(state, variables), None

        new_dynamic = jit(new_dynamic)
        with jax.default_device(target):
            final_state, _ = jax.lax.scan(
                new_dynamic, initial_state, time_dependent_variables, length=time_steps
            )
        return final_state
