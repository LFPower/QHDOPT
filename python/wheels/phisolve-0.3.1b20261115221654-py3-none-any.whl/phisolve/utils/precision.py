"""Shared preparation for real host coefficient arithmetic."""

from numbers import Number

import numpy as np
from scipy import sparse


def promote_prepared_quadratic(value):
    """Choose arithmetic precision for an already checked quadratic operand.

    Keep host/sparse float64 arithmetic and promote narrow JAX values before
    halving. A concrete wider JAX value may outlive its x64 configuration;
    retain that value on the host until its skew component has canceled.
    Call before slicing a captured concrete JAX array turns it into a tracer.
    """
    import jax

    dtype = np.dtype(np.float64 if jax.config.x64_enabled else np.float32)

    if isinstance(value, jax.Array) and value.dtype.itemsize > dtype.itemsize:
        return np.asarray(value)
    if isinstance(value, (jax.Array, jax.core.Tracer)) and value.dtype.itemsize < dtype.itemsize:
        return value.astype(dtype)
    return value


def average_prepared_quadratic_blocks(left, right):
    """Average checked blocks without premature underflow or sum overflow."""
    left, right = promote_prepared_quadratic(left), promote_prepared_quadratic(right)
    with np.errstate(over="ignore", invalid="ignore", under="ignore"):
        total = left + right
        if sparse.issparse(total):
            # Addition creates independent canonical storage. Normally sum
            # before halving, preserving tiny entries that finite box scaling
            # can later amplify. Only overflowing entries need half-first math.
            total = total.tocsr()
            overflow = ~np.isfinite(total.data)
            if np.any(overflow):
                coordinates = total.tocoo(copy=False)
                half_first = (0.5 * left + 0.5 * right).tocsr()
                replacements = np.asarray(half_first[
                    coordinates.row[overflow], coordinates.col[overflow]
                ]).reshape(-1)
            total.data *= 0.5
            if np.any(overflow):
                total.data[overflow] = replacements
            return total

        import jax
        import jax.numpy as jnp

        xp = jnp if isinstance(total, (jax.Array, jax.core.Tracer)) else np
        return xp.where(xp.isfinite(total), 0.5 * total, 0.5 * left + 0.5 * right)


def normalize_arraylike(value):
    """Expose host arraylike storage without promoting its numeric dtype.

    Preserve list/object structure so integers cannot disappear through mixed
    floating promotion. JAX leaves and sparse storage keep their own paths.
    Only containers with replaced leaves are copied; caller data is not edited.
    """
    import jax

    if isinstance(value, (jax.Array, jax.core.Tracer)) or sparse.issparse(value):
        return value
    if isinstance(value, np.ndarray):
        if value.dtype.kind != "O":
            return value
        result = value
        for index in np.ndindex(value.shape):
            item = value[index]
            normalized = normalize_arraylike(item)
            if normalized is not item:
                if result is value:
                    result = value.copy()
                result[index] = normalized
        return result
    if isinstance(value, (list, tuple)):
        items = [normalize_arraylike(item) for item in value]
        if all(item is original for item, original in zip(items, value)):
            return value
        return tuple(items) if isinstance(value, tuple) else items
    # np.isscalar also calls memoryview a scalar, despite its numeric buffer.
    if isinstance(value, (Number, np.generic, str, bytes)):
        return value
    array = np.asarray(value)
    # Some scalar objects (for example Decimal) box themselves instead of
    # exposing array storage. Leave their numeric conversion to the caller.
    if array.ndim == 0 and array.dtype.kind == "O" and array.item() is value:
        return value
    return normalize_arraylike(array)


def _contains_jax(value):
    """Find JAX leaves without materializing arrays or tracers."""
    import jax

    if isinstance(value, (jax.Array, jax.core.Tracer)):
        return True
    if isinstance(value, (list, tuple)):
        return any(_contains_jax(item) for item in value)
    if isinstance(value, np.ndarray) and value.dtype.kind == "O":
        return any(_contains_jax(item) for item in value.flat)
    return False


def check_jax_integer_precision(original, prepared, name="coefficient"):
    """Check original integer provenance at a JAX arithmetic boundary.

    ``prepared`` may be an already-prepared subset of an integer array. Sparse
    duplicate sums are checked in canonical prepared storage, so exact integer
    cancellation can occur before conversion. For mixed containers, pass the
    corresponding original subset to preserve which entries were integers.
    Floating inputs retain the caller's ordinary execution-precision policy.
    """
    import jax

    original = normalize_arraylike(original)
    if isinstance(original, (jax.Array, jax.core.Tracer)):
        # A JAX leaf may have arrived through a list or object array. Check the
        # original leaf, not a potentially rounded surrounding container.
        prepare_float64_coefficient(original, name, preserve_jax=True)
        return
    target_dtype = np.dtype(np.float64 if jax.config.x64_enabled else np.float32)

    def check_values(values):
        if isinstance(values, (jax.Array, jax.core.Tracer)):
            # Container assembly may have put a host integer on a traced path.
            # Its original host value is still available for a static check.
            from phisolve.validation import as_float64_exact

            values = as_float64_exact(original, name)
        values = values.data if sparse.issparse(values) else np.asarray(values)
        # Preparation has already established float64 integer exactness.
        if target_dtype == np.dtype(np.float64):
            return
        iterator = np.nditer(values, flags=["external_loop", "buffered", "zerosize_ok"],
                             op_flags=["readonly"], buffersize=4096)
        with np.errstate(over="ignore", invalid="ignore"):
            for chunk in iterator:
                if not np.array_equal(chunk, chunk.astype(target_dtype).astype(np.float64)):
                    raise ValueError(
                        f"{name} integers cannot be represented losslessly in "
                        f"JAX's {target_dtype} execution precision"
                    )

    if sparse.issparse(original):
        if original.dtype.kind in "biu":
            check_values(prepared)
    elif isinstance(original, np.ndarray):
        if original.dtype.kind in "biu":
            check_values(prepared)
        elif original.dtype.kind == "O":
            for index in np.ndindex(original.shape):
                check_jax_integer_precision(original[index], prepared[index], name)
    elif isinstance(original, (list, tuple)):
        for item, value in zip(original, prepared):
            check_jax_integer_precision(item, value, name)
    elif isinstance(original, (int, np.integer, bool, np.bool_)):
        check_values(prepared)


def prepare_jax_coefficient(value, name="coefficient"):
    """Prepare a coefficient and guard integer precision before JAX execution.

    Pure host results remain host arrays/sparse storage. Containers with JAX
    leaves are assembled only after each leaf is checked, preserving tracing.
    """
    import jax

    value = normalize_arraylike(value)
    prepared = prepare_float64_coefficient(value, name, preserve_jax=True)
    if not isinstance(value, (jax.Array, jax.core.Tracer)):
        check_jax_integer_precision(value, prepared, name)
    return prepared


def prepare_float64_coefficient(value, name="coefficient", preserve_jax=False):
    """Prepare real coefficients without mutating sources or densifying.

    Integer inputs and their duplicate-entry sums must be exactly representable
    in float64. Sparse integer duplicates are summed as Python integers before
    conversion, avoiding both narrow-integer overflow and floating cancellation.
    Sparse results are independent canonical CSR storage. ``preserve_jax``
    leaves floating JAX arrays/tracers on their existing arithmetic path.
    Concrete JAX integers are cast only after checking exactness in the current
    JAX floating precision. Integer tracers are supported only when their whole
    dtype fits that precision; wider dynamic integers must be validated and
    converted to an exactly representable floating dtype before jitting.

    The validator import is deliberately lazy: problem classes import numerical
    helpers while validation itself imports those problem classes.
    """
    value = normalize_arraylike(value)
    if preserve_jax:
        import jax
        import jax.numpy as jnp

        if isinstance(value, (jax.Array, jax.core.Tracer)):
            from phisolve.validation import check_real_values

            # Preserving a JAX leaf bypasses host conversion, so apply the
            # same real-valued contract using its static dtype first.
            check_real_values(value, name)
            source_dtype = np.dtype(value.dtype)
            is_integer = jnp.issubdtype(source_dtype, jnp.integer)
            is_boolean = jnp.issubdtype(source_dtype, jnp.bool_)
            # JAX's sub-byte integers use NumPy kind 'V'; dtype.kind alone
            # would leave their products in overflowing integer arithmetic.
            if not (is_integer or is_boolean):
                return value
            target_dtype = np.dtype(np.float64 if jax.config.x64_enabled else np.float32)
            if isinstance(value, jax.core.Tracer):
                if is_integer:
                    limits = jnp.iinfo(source_dtype)
                    exact_limit = 2 ** (np.finfo(target_dtype).nmant + 1)
                    if limits.min < -exact_limit or limits.max > exact_limit:
                        raise ValueError(
                            f"Cannot convert traced {source_dtype} {name} losslessly "
                            f"to {target_dtype}; validate the integer values and "
                            "convert them to an exactly representable floating "
                            "dtype before jitting"
                        )
            else:
                from phisolve.validation import as_float64_exact

                original = as_float64_exact(np.asarray(value), name)
                with np.errstate(over="ignore", invalid="ignore"):
                    converted = original.astype(target_dtype)
                if not np.array_equal(original, converted.astype(np.float64)):
                    raise ValueError(
                        f"{name} integers cannot be represented losslessly in "
                        f"JAX's {target_dtype} execution precision"
                    )
            # Cast on the existing device, preserving the immutable source.
            return value.astype(target_dtype)

        if _contains_jax(value):
            # NumPy conversion would both erase integer provenance and reject
            # floating tracers. Prepare each leaf before JAX assembles a
            # rectangular array. Object arrays need their structure unwrapped
            # because JAX does not accept object dtype storage.
            if isinstance(value, np.ndarray):
                value = value.tolist()
            if not isinstance(value, (list, tuple)):
                return prepare_jax_coefficient(value, name)
            return jnp.asarray([prepare_jax_coefficient(item, name) for item in value])

    from phisolve.validation import as_float64_exact

    if not sparse.issparse(value):
        return as_float64_exact(value, name)

    coo = value.tocoo(copy=False)
    as_float64_exact(coo.data, name)
    if value.dtype.kind in "iu" and not getattr(value, "has_canonical_format", False):
        sums = {}
        coordinates = coo.coords if coo.ndim == 1 else (coo.row, coo.col)
        for entry in zip(*coordinates, coo.data):
            key = tuple(int(index) for index in entry[:-1])
            item = entry[-1]
            sums[key] = sums.get(key, 0) + int(item)
        data = as_float64_exact(list(sums.values()), name)
        indices = tuple(
            np.fromiter((key[axis] for key in sums), dtype=np.int64, count=len(sums))
            for axis in range(coo.ndim)
        )
        constructor = sparse.coo_matrix if sparse.isspmatrix(value) else sparse.coo_array
        prepared = constructor((data, indices), shape=value.shape).tocsr()
    else:
        prepared = value.astype(np.float64, copy=True).tocsr()
        prepared.sum_duplicates()
    return prepared
