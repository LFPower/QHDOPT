from os.path import isfile, join
import numpy as np
import scipy as sp
from phisolve.problems.qubo import QUBO
from phisolve.problems.boxqp import BoxQP
from phisolve.problems.lcqp import LCQP
from phisolve.problems.miqp import MIQP
from phisolve.utils.precision import prepare_float64_coefficient
from typing import Union

def open_QP_file(file_name):
    with open(f"{file_name}.npy", "rb") as f:
        Q = np.load(f)
        b = np.load(f)
    return Q, b


def save_qubo(filename, Q, w, sol, objective_sense="min"):
    """Save QUBO problem data to a file using ``.npz`` format.

    Parameters
    ----------
    filename: str
    Q: array or csc_matrix
    w: array
    sol: array or str
    objective_sense: str ('min' or 'max')
    """
    if type(Q) == np.ndarray:
        np.savez(
            filename,
            problem_type="qubo",
            objective_sense=objective_sense,
            Q_type="dense",
            Q=Q,
            w=w,
            sol=sol,
        )

    elif type(Q) == sp.sparse._csc.csc_matrix:
        np.savez(
            filename,
            problem_type="qubo",
            objective_sense=objective_sense,
            Q_type="sparse",
            Q_data=Q.data,
            Q_indices=Q.indices,
            Q_indptr=Q.indptr,
            Q_shape=Q.shape,
            w=w,
            sol=sol,
        )

    else:
        raise TypeError("Q matrix type not supported.")


def save_boxqp(filename, Q, w, l, u, sol, objective_sense="min"):
    """Save BoxQP problem data to a file using ``.npz`` format.

    Parameters
    ----------
    filename: str
    Q: array or csc_matrix
    w: array
    l: array
    u: array
    sol: array or str
    objective_sense: str ('min' or 'max')
    """
    if type(Q) == np.ndarray:
        np.savez(
            filename,
            problem_type="boxqp",
            objective_sense=objective_sense,
            Q_type="dense",
            Q=Q,
            w=w,
            l=l,
            u=u,
            sol=sol,
        )

    elif type(Q) == sp.sparse._csc.csc_matrix:
        np.savez(
            filename,
            problem_type="boxqp",
            objective_sense=objective_sense,
            Q_type="sparse",
            Q_data=Q.data,
            Q_indices=Q.indices,
            Q_indptr=Q.indptr,
            Q_shape=Q.shape,
            w=w,
            l=l,
            u=u,
            sol=sol,
        )
    else:
        raise TypeError("Q matrix type not supported.")



def _matrix_fields(name, matrix):
    """Encode one dense/CSC matrix using the existing NPZ field schema."""
    if isinstance(matrix, np.ndarray):
        return {name + "_type": "dense", name: matrix}
    if isinstance(matrix, sp.sparse.csc_matrix):
        return {
            name + "_type": "sparse", name + "_data": matrix.data,
            name + "_indices": matrix.indices, name + "_indptr": matrix.indptr,
            name + "_shape": matrix.shape,
        }
    raise TypeError(f"{name} matrix type not supported.")


def save_lcqp(filename, Q, w, A, b, C, d, l, u, sol, objective_sense="min"):
    """Save LCQP problem data to a file using `.npz` format.

    The LCQP problem is given by:
    min f(x) = 0.5 * x @ Q @ x + w @ x
    subject to A @ x <= b, C @ x = d, l <= x <= u

    Parameters
    ----------
    filename: str
    Q: array or csc_matrix
    w: array
    A: array or csc_matrix
    b: array
    C: array or csc_matrix
    d: array
    l: array
    u: array
    sol: array or str
    objective_sense: str, ('min' or 'max')
    """
    np.savez(
        filename, problem_type="lcqp", objective_sense=objective_sense,
        **_matrix_fields("Q", Q), w=w, **_matrix_fields("A", A), b=b,
        **_matrix_fields("C", C), d=d, l=l, u=u, sol=sol,
    )


def save_miqp(
    filename, Q, w, A, b, C, d, l, u, n_binary_vars, sol, objective_sense="min"
):
    """Save MIQP problem data to a file using ``.npz`` format.

    The MIQP problem is given by:
    minimize f(x) = 0.5 * x.T @ Q @ x + w.T @ x
    subject to: Ax <= b, Cx = d,
                l_i <= x_i <= u_i.
                for all i in I, x_i is in {l_i, u_i}

    Parameters
    ----------
    Q : array or csc_matrix
    w : np.ndarray
    A : array or csc_matrix
    b : np.ndarray
    C : array or csc_matrix
    d : np.ndarray
    bounds: Tuple
    n_binary_vars : int
    """

    np.savez(
        filename, problem_type="miqp", objective_sense=objective_sense,
        **_matrix_fields("Q", Q), w=w, **_matrix_fields("A", A), b=b,
        **_matrix_fields("C", C), d=d, l=l, u=u,
        n_binary_vars=n_binary_vars, sol=sol,
    )


def _load_objective(buffer):
    """Prepare independent floating operands before folding or sign changes."""
    Q = prepare_float64_coefficient(read_2d_mat_from_buffer(buffer, "Q"), "Q")
    # Preserve the CSC representation accepted by the public file writers.
    if sp.sparse.issparse(Q):
        Q = Q.tocsc()
    w = prepare_float64_coefficient(buffer["w"], "w")
    return Q, w


def _load_binary_count(value, nvar):
    """Decode an integer scalar archive field without accepting coerced data."""
    if value.ndim != 0 or value.dtype.kind not in "iu":
        raise ValueError("n_binary_vars must be an integer scalar between 0 and nvar")
    count = int(value)
    if not 0 <= count <= nvar:
        raise ValueError("n_binary_vars must be an integer scalar between 0 and nvar")
    return count

def read_2d_mat_from_buffer(buffer, s):
    if s+"_type" not in buffer:
        return buffer[s]
    elif buffer[s+"_type"] == "dense":
        return buffer[s]
    elif buffer[s+"_type"] == "sparse":
        cls = getattr(sp.sparse, "csc_matrix")
        M = cls(
            (buffer[s+"_data"], buffer[s+"_indices"], buffer[s+"_indptr"]),
            shape=buffer[s+"_shape"],
        )
        return M
    else:
        ValueError(s + "matrix type not supported.")

def load_instance(filename):
    """Load a problem instance from a file using ``.npz`` format.

    Returned models minimize the stored objective (negated for maximization).
    Objective coefficients are checked and promoted before sign changes and
    QUBO diagonal folding. MIQP binary counts must be integer scalar metadata.
    Boolean, integer and real floating reference-solution arrays retain their
    shape, dtype and values. These are unvalidated metadata, not a feasibility
    or optimality certificate. Strings and other unsupported representations
    retain the legacy ``None`` result.

    Parameters
    ----------
    filename: str
    """
    with np.load(filename, allow_pickle=True) as buffer:
        sign = 1 if buffer["objective_sense"] == "min" else -1
        reference = buffer["sol"]
        sol = reference if reference.dtype.kind in "biuf" else None

        if buffer["problem_type"] == "qubo":
            Q, w = _load_objective(buffer)
            if w.shape != (Q.shape[0],):
                raise ValueError("w must contain one linear coefficient per variable")
            # x_i**2 == x_i on the binary domain; off-diagonal entries stay put.
            diagonal = sp.sparse.diags(w, format="csc") if sp.sparse.issparse(Q) else np.diag(w)
            return QUBO(sign * (Q + 2 * diagonal)), sol

        elif buffer["problem_type"] == "boxqp":
            Q, w = _load_objective(buffer)
            l = buffer["l"]
            u = buffer["u"]
            return (
                BoxQP(
                    sign * Q,
                    sign * w,
                    (l, u),
                ),
                sol,
            )

        elif buffer["problem_type"] == "lcqp":
            Q, w = _load_objective(buffer)
            A = read_2d_mat_from_buffer(buffer, "A")
            b = buffer["b"]
            C = read_2d_mat_from_buffer(buffer, "C")
            d = buffer["d"]
            l = buffer["l"]
            u = buffer["u"]
            return (
                LCQP(
                    Q=sign * Q,
                    w=sign * w,
                    A=A,
                    b=b,
                    C=C,
                    d=d,
                    bounds=(l, u),
                ),
                sol,
            )

        elif buffer["problem_type"] == "miqp":
            Q, w = _load_objective(buffer)
            A = read_2d_mat_from_buffer(buffer, "A")
            b = buffer["b"]
            C = read_2d_mat_from_buffer(buffer, "C")
            d = buffer["d"]
            l = buffer["l"]
            u = buffer["u"]
            n_binary_vars = _load_binary_count(buffer["n_binary_vars"], Q.shape[0])
            return (
                MIQP(
                    Q=sign * Q,
                    w=sign * w,
                    A=A,
                    b=b,
                    C=C,
                    d=d,
                    bounds=(l, u),
                    n_binary_vars=n_binary_vars
                ),
                sol,
            )
