from jax import numpy as jnp
import jax
import math
import numpy as np
from jax.experimental import sparse as jsp
import scipy as sp
from functools import partial
from phisolve.utils.precision import prepare_float64_coefficient

def jax_device(device):
    if device == "gpu":
        return "cuda"
    return device


def _l2_components(data, xp):
    """Normalize components with finite powers of two, never a tiny reciprocal."""
    data = xp.asarray(data)
    if not xp.issubdtype(data.dtype, xp.inexact):
        data = data.astype(xp.result_type(data, 0.0))
    result_dtype = data.real.dtype
    data = data.astype(xp.result_type(data.dtype, xp.float32))
    real = data.real
    scale = xp.max(xp.abs(real))
    if xp.iscomplexobj(data):
        imag = data.imag
        scale = xp.maximum(scale, xp.max(xp.abs(imag)))
    finite = xp.isfinite(scale)
    _, exponent = xp.frexp(xp.where(finite, scale, 0))
    limit = xp.finfo(real.dtype).maxexp - 1
    # Use the lower bounding power of two. Using frexp's upper bound can
    # turn a normal unit component into a subnormal intermediate, which JAX
    # devices may flush to zero before the norm's derivative is formed.
    exponent = xp.clip(exponent - 1, -limit, limit)
    real = xp.ldexp(xp.where(finite, real, 0), -exponent)
    imag = (xp.ldexp(xp.where(finite, data.imag, 0), -exponent)
            if xp.iscomplexobj(data) else None)
    return data, result_dtype, scale, finite, exponent, real, imag


def _host_l2_overflows(data, result_dtype):
    """Compare finite components with the exact result-dtype overflow midpoint.

    Scalar ratios preserve the host working precision, including extended
    types. Their denominators are powers of two, so integer shifts express
    every square in units of the working dtype's smallest subnormal squared.
    This rare boundary check does not rely on a rounded square root or hypot.
    """
    work_info = np.finfo(data.real.dtype)
    result_info = np.finfo(result_dtype)
    smallest_exponent = work_info.minexp - work_info.nmant
    precision = result_info.nmant + 1
    threshold = ((1 << (precision + 1)) - 1) ** 2 << (
        2 * (result_info.maxexp - precision - 1 - smallest_exponent))
    total = 0
    parts = (data.real, data.imag) if np.iscomplexobj(data) else (data.real,)
    for part in parts:
        for component in part.flat:
            if component == 0:
                continue
            numerator, denominator = component.as_integer_ratio()
            shift = -2 * (smallest_exponent + denominator.bit_length() - 1)
            total += (numerator * numerator) << shift
            # All remaining squares are nonnegative; a tie rounds to infinity.
            if total >= threshold:
                return True
    return False


def _jax_l2_overflows(data, result_dtype, needed):
    """Exactly classify the rare overflow boundary using device integers.

    IEEE components are integers times a common power of two. Accumulate their
    squares in half-word limbs and compare with the squared round-to-nearest
    overflow midpoint of the *result* dtype. This avoids relying on a rounded
    sum/square root to decide whether a finite norm should become infinity.
    The loop is skipped away from the boundary, also when transformed by vmap.
    """
    components = (jnp.concatenate((data.real, data.imag))
                  if jnp.iscomplexobj(data) else data)
    work_info = jnp.finfo(components.dtype)
    result_info = jnp.finfo(result_dtype)
    word_dtype = jnp.uint64 if components.dtype.itemsize == 8 else jnp.uint32
    limb_bits = 32 if components.dtype.itemsize == 8 else 16
    limb_mask = (1 << limb_bits) - 1
    smallest_exponent = work_info.minexp - work_info.nmant
    # Include enough headroom even if many components are added before the
    # threshold is crossed. The positive sum can stop as soon as it crosses.
    bit_count = (2 * (work_info.maxexp - smallest_exponent)
                 + (components.size - 1).bit_length())
    # An extra zero limb also accommodates the fixed five-digit insertion
    # when the highest shifted digit happens to be zero.
    limb_count = (bit_count + limb_bits - 1) // limb_bits + 1
    precision = result_info.nmant + 1
    threshold_integer = ((1 << (precision + 1)) - 1) ** 2 << (
        2 * (result_info.maxexp - precision - 1 - smallest_exponent))
    threshold = jnp.asarray([
        (threshold_integer >> (limb_bits * i)) & limb_mask
        for i in range(limb_count)
    ], dtype=word_dtype)
    positions = jnp.arange(limb_count)
    mask = jnp.asarray(limb_mask, dtype=word_dtype)
    shift_width = jnp.asarray(limb_bits, dtype=word_dtype)

    def at_threshold(accumulator):
        different = accumulator != threshold
        last = jnp.max(jnp.where(different, positions, 0))
        # Ties at the overflow midpoint round to infinity (the even endpoint).
        return (~jnp.any(different)
                | (accumulator[last] > threshold[last]))

    def add_component(state):
        index, accumulator, _ = state
        bits = jax.lax.bitcast_convert_type(components[index], word_dtype)
        exponent = ((bits >> work_info.nmant)
                    & ((1 << work_info.nexp) - 1))
        significand = ((bits & ((1 << work_info.nmant) - 1))
                       | jnp.where(exponent != 0,
                                   word_dtype(1 << work_info.nmant), word_dtype(0)))
        low, high = significand & mask, significand >> shift_width
        # Each product fits in one word: the high half of an IEEE significand
        # has only 8 (float32) or 21 (float64) occupied bits.
        product0 = low * low
        product1 = word_dtype(2) * low * high
        product2 = high * high
        middle1 = (product0 >> shift_width) + (product1 & mask)
        middle2 = ((product1 >> shift_width) + (product2 & mask)
                   + (middle1 >> shift_width))
        square = jnp.stack((product0 & mask, middle1 & mask,
                            middle2 & mask,
                            (product2 >> shift_width) + (middle2 >> shift_width)))
        power = 2 * (jnp.maximum(exponent, word_dtype(1)) - word_dtype(1))
        offset = (power // shift_width).astype(jnp.int32)
        remainder = power % shift_width
        lower = (square << remainder) & mask
        upper = square >> (shift_width - remainder)
        zero = jnp.zeros((1,), dtype=word_dtype)
        digits = (jnp.concatenate((lower, zero))
                  | jnp.concatenate((zero, upper)))

        def add_digit(i, carry_state):
            acc, carry = carry_state
            total = acc[offset + i] + digits[i] + carry
            return acc.at[offset + i].set(total & mask), total >> shift_width

        accumulator, carry = jax.lax.fori_loop(
            0, 5, add_digit, (accumulator, word_dtype(0)))

        def carry_needed(carry_state):
            _, _, pending = carry_state
            return pending != 0

        def propagate(carry_state):
            acc, position, pending = carry_state
            total = acc[position] + pending
            return acc.at[position].set(total & mask), position + 1, total >> shift_width

        accumulator, _, _ = jax.lax.while_loop(
            carry_needed, propagate, (accumulator, offset + 5, carry))
        return index + 1, accumulator, at_threshold(accumulator)

    def component_needed(state):
        index, _, overflow = state
        return needed & (index < components.size) & ~overflow

    _, _, overflow = jax.lax.while_loop(
        component_needed, add_component,
        (jnp.asarray(0, dtype=jnp.int32),
         jnp.zeros((limb_count,), dtype=word_dtype), jnp.asarray(False)))
    return overflow


def _scaled_l2_norm(data, xp):
    """Euclidean norm without squaring the original magnitudes.

    Scale real and imaginary components by bounded powers of two. A reciprocal
    of a large finite scale can be flushed to zero during eager JAX division.
    Narrow floating arrays accumulate in at least float32, then retain the
    ordinary norm's real result dtype.
    """
    data, result_dtype, scale, finite, exponent, real, imag = _l2_components(data, xp)
    if xp is np and (scale == 0 or not np.isfinite(scale)):
        return np.asarray(scale, dtype=result_dtype)[()]
    squared = xp.sum(real * real)
    if imag is not None:
        squared = squared + xp.sum(imag * imag)
    if xp is np:
        # Neither rounded reconstruction nor hypot alone can reliably classify
        # the overflow boundary. Decide it exactly in the final result dtype,
        # retaining the robust component norm for the finite magnitude.
        with np.errstate(over="ignore"):
            value = np.ldexp(np.sqrt(squared), exponent)
        maximum = np.finfo(result_dtype).max
        boundary = value >= maximum / 2
        if boundary:
            if _host_l2_overflows(data, result_dtype):
                return np.asarray(np.inf, dtype=result_dtype)[()]
            if data.real.dtype.itemsize <= np.dtype(np.float64).itemsize:
                value = (math.hypot(*data.real, *data.imag) if np.iscomplexobj(data)
                         else math.hypot(*data))
            else:
                # Preserve extended host precision rather than narrowing its
                # components to Python floats for the boundary fallback.
                components = (np.concatenate((data.real, data.imag))
                              if np.iscomplexobj(data) else data)
                with np.errstate(over="ignore"):
                    value = np.hypot.reduce(components)
        with np.errstate(over="ignore"):
            result = np.asarray(value, dtype=result_dtype)[()]
        # The exact comparison above proved this result must remain finite.
        # Repair overflow from hypot or a final narrowing cast, not genuine
        # overflow (which already returned infinity).
        if boundary and np.isinf(result):
            return np.asarray(maximum, dtype=result_dtype)[()]
        return result
    value = xp.ldexp(xp.sqrt(squared), exponent)
    maximum = xp.asarray(xp.finfo(result_dtype).max, dtype=data.real.dtype)
    boundary = finite & (value >= maximum / 2)
    overflow = _jax_l2_overflows(data, result_dtype, boundary)
    result = xp.asarray(value, dtype=result_dtype)
    # Correct either direction only after the exact comparison, including
    # overflow introduced by a final float16/bfloat16 cast from float32.
    result = xp.where(overflow, xp.asarray(xp.inf, dtype=result_dtype),
                      xp.where(boundary & xp.isinf(result),
                               xp.asarray(maximum, dtype=result_dtype), result))
    return xp.where(finite, result, xp.asarray(scale, dtype=result_dtype))


@jax.custom_jvp
def _jax_l2_norm(data):
    return _scaled_l2_norm(data, jnp)


@_jax_l2_norm.defjvp
def _jax_l2_norm_jvp(primals, tangents):
    data, = primals
    tangent, = tangents
    value = _jax_l2_norm(data)
    if tangent.dtype == jax.dtypes.float0:
        return value, jnp.zeros_like(value)
    _, _, _, _, _, real, imag = _l2_components(data, jnp)
    squared = jnp.sum(real * real)
    if imag is not None:
        squared = squared + jnp.sum(imag * imag)
    normalized_norm = jnp.sqrt(squared)
    # Differentiate using unit components. Scaling the tangent by the input's
    # exponent first could flush a perfectly representable derivative to zero.
    directional = jnp.sum((real / normalized_norm) * tangent.real)
    if imag is not None:
        directional = directional + jnp.sum((imag / normalized_norm) * tangent.imag)
    return value, jnp.asarray(directional, dtype=value.dtype)


def entrywise_norm(mat, ord=2):
    """Vector norm of all entries, preserving the legacy dense recipe.

    In particular, ord=2 is the Frobenius norm and ord=inf is maximum
    absolute entry, not the spectral or maximum-row-sum matrix norm.
    Integer entries and duplicate sums are checked before float64 arithmetic.
    The Euclidean/Frobenius case uses scaled sums of squares, including complex
    components, to avoid avoidable overflow and underflow. No dense matrix is
    allocated for sparse inputs.
    """
    if sp.sparse.issparse(mat):
        if np.issubdtype(mat.dtype, np.complexfloating):
            canonical = mat.tocsr(copy=True)
            canonical.sum_duplicates()
        else:
            canonical = prepare_float64_coefficient(mat, "matrix")
        data = canonical.data
        if ord is not None and ord < 0 and canonical.nnz < np.prod(mat.shape):
            data = np.append(data, 0.0)
        if data.size == 0:
            return 0.0
        if ord is None or ord == 2:
            return _scaled_l2_norm(data, np)
        return np.linalg.norm(data, ord=ord)
    if isinstance(mat, np.ndarray) and not np.iscomplexobj(mat):
        mat = prepare_float64_coefficient(mat, "matrix")
    if mat.size == 0:
        return 0.0
    xp = np if isinstance(mat, np.ndarray) else jnp
    if ord is None or ord == 2:
        return (_scaled_l2_norm(mat.reshape(-1), np) if xp is np
                else _jax_l2_norm(mat.reshape(-1)))
    return xp.linalg.norm(mat.reshape(-1), ord=ord)


def max_abs_entry(mat):
    """Maximum absolute matrix/vector entry; zero for an empty matrix."""
    return entrywise_norm(mat, ord=np.inf)


def frobenius_norm(mat):
    """Square root of the sum of squared absolute entries."""
    return entrywise_norm(mat, ord=2)


def mat_norm(mat, ord=2):
    """Compatibility alias for the representation-independent entrywise norm."""
    return entrywise_norm(mat, ord=ord)

def inf_norm(mat):
    return max_abs_entry(mat)

def mat_square(mat):
    if isinstance(mat, sp.sparse.spmatrix):
        return mat.multiply(mat)
    else:
        return mat ** 2

def sp_sparse_mat_to_jsp_BCOO(sp_mat):
    sp_mat_coo = sp_mat.tocoo()
    data = jnp.array(sp_mat_coo.data)
    indices_np = np.stack((sp_mat_coo.row, sp_mat_coo.col)).T
    indices = jnp.array(indices_np)
    shape = sp_mat_coo.shape
    return jsp.BCOO((data, indices), shape=shape)

def sp_sparse_mat_to_jsp_BCSR(sp_mat):
    return jsp.BCSR.from_scipy_sparse(sp_mat)

# A matrix-vector multiplication compatible with sparse M in JAX's sparse format
def spcomp_matvec(M, v):
    if sp.sparse.issparse(M):
        M = sp_sparse_mat_to_jsp_BCSR(prepare_float64_coefficient(M, "matrix"))
    return M @ v
    
def to_dense_mat(M):
    if sp.sparse.issparse(M):
        if not np.issubdtype(M.dtype, np.complexfloating):
            M = prepare_float64_coefficient(M, "matrix")
        return M.toarray()
    return M
