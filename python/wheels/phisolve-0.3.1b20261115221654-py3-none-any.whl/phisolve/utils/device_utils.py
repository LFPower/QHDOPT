"""Explicit single-device placement shared by solver execution paths."""

import jax


def resolve_device(device="cpu"):
    """Resolve a platform alias or an available concrete JAX device.

    String aliases select the first device on that platform. This function does
    not imply multi-device execution or change process-wide JAX configuration.
    """
    if isinstance(device, jax.Device):
        if device not in jax.local_devices(backend=device.platform):
            raise ValueError(f"Device {device} is not locally available")
        return device
    if not isinstance(device, str):
        raise ValueError("device must be 'cpu', 'gpu', 'cuda', 'tpu', or a JAX device")
    platform = {"cuda": "gpu"}.get(device.lower(), device.lower())
    if platform not in {"cpu", "gpu", "tpu"}:
        raise ValueError(f"Unsupported device platform: {device!r}")
    try:
        devices = jax.local_devices(backend=platform)
    except RuntimeError as exc:
        raise ValueError(f"Requested device platform {platform!r} is unavailable") from exc
    if not devices:
        raise ValueError(f"Requested device platform {platform!r} is unavailable")
    return devices[0]
