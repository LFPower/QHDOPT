"""Independent CPU checks of candidates in the original problem coordinates."""

from dataclasses import dataclass

import jax
import numpy as np
from scipy import sparse

from phisolve.problems.qubo import QUBO
from phisolve.utils.precision import normalize_arraylike, prepare_float64_coefficient


@dataclass(frozen=True)
class CandidateValidation:
    """Original objective and absolute constraint residuals for one candidate.

    Unavailable residuals are infinite. A finite objective does not imply that
    the candidate is feasible, and validity does not imply optimality.
    """

    valid: bool
    objective: float | None = None
    reason: str | None = None
    max_bound_violation: float = np.inf
    max_binary_violation: float = np.inf
    max_inequality_violation: float = np.inf
    max_equality_violation: float = np.inf

    @property
    def max_violation(self):
        return max(
            self.max_bound_violation,
            self.max_binary_violation,
            self.max_inequality_violation,
            self.max_equality_violation,
        )


def _tolerance(value, name):
    value = float(value)
    if not np.isfinite(value) or value < 0:
        raise ValueError(f"{name} must be finite and nonnegative")
    return value


def check_real_values(value, name="value"):
    """Reject complex leaves and records without materializing JAX tracers.

    NumPy's outer dtype check does not inspect object-array contents. Inspect
    those leaves before any floating conversion can discard an imaginary part.
    Complex dtype is unsupported even when its imaginary components are zero.
    Finiteness is deliberately left to the caller.
    """
    if isinstance(value, (np.ndarray, np.generic)) and value.dtype.fields is not None:
        # NumPy can cast single-field records directly to float, bypassing the
        # real/integer checks on their fields. Records are not numeric operands.
        # Check fields rather than kind 'V': sub-byte numeric dtypes also use V.
        raise ValueError(f"{name} must be numeric; structured records are not supported")
    if isinstance(value, (jax.Array, jax.core.Tracer)):
        if np.dtype(value.dtype).kind == "c":
            raise ValueError(f"{name} must be real")
    elif isinstance(value, np.ndarray) or sparse.issparse(value):
        if value.dtype.kind == "c":
            raise ValueError(f"{name} must be real")
        if isinstance(value, np.ndarray) and value.dtype.kind == "O":
            for item in value.flat:
                check_real_values(item, name)
    elif isinstance(value, (list, tuple)):
        for item in value:
            check_real_values(item, name)
    elif np.iscomplexobj(value):
        raise ValueError(f"{name} must be real")


def _check_exact_integers(value, name):
    """Reject integer values rounded by float64, using bounded working buffers."""
    message = f"{name} contains integers that cannot be represented losslessly in float64"
    if isinstance(value, jax.core.Tracer):
        raise ValueError(
            f"{name} contains a JAX tracer; host validation requires concrete values"
        )
    if isinstance(value, jax.Array):
        # Inspect a device leaf before a surrounding mixed list or object array
        # can promote it to floating point and erase its integer provenance.
        value = np.asarray(value)
    if isinstance(value, np.ndarray):
        if value.dtype.kind in "iu":
            if value.dtype.itemsize <= 4:
                return
            # Avoid an additional full-matrix roundtrip copy for every candidate.
            # Casting float64 back to an integer at its signed/unsigned boundary
            # can warn; a mismatched roundtrip is the intended rejection there.
            for start in range(0, value.size, 4096):
                chunk = value.flat[start:start + 4096]
                with np.errstate(over="ignore", invalid="ignore"):
                    restored = chunk.astype(np.float64).astype(value.dtype)
                if not np.array_equal(chunk, restored):
                    raise ValueError(message)
        elif value.dtype.kind == "O":
            for item in value.flat:
                _check_exact_integers(item, name)
    elif isinstance(value, (list, tuple)):
        # Check before NumPy promotes a mixed list of integers and floats.
        for item in value:
            _check_exact_integers(item, name)
    elif isinstance(value, (int, np.integer)):
        integer = int(value)
        try:
            converted = float(integer)
        except OverflowError as exc:
            raise ValueError(message) from exc
        if not np.isfinite(converted) or int(converted) != integer:
            raise ValueError(message)


def as_float64_exact(value, name="value"):
    """Convert real numeric data to float64 without rounding integer inputs.

    Exactly representable large integers remain supported. Integer values that
    would round or overflow raise ``ValueError``. Finite-value policy is left
    to the caller, so continuous infinite bounds can still be represented.
    """
    # Expose wrapper leaves before a surrounding mixed container can promote
    # their original integer storage to floating point.
    value = normalize_arraylike(value)
    check_real_values(value, name)
    if isinstance(value, (list, tuple, jax.core.Tracer)):
        _check_exact_integers(value, name)
    try:
        array = np.asarray(value)
        # Arraylike wrappers can expose object storage only after conversion.
        # Check that storage too, before a float cast can discard imaginary parts.
        check_real_values(array, name)
        _check_exact_integers(array, name)
        return np.asarray(array, dtype=np.float64)
    except (TypeError, OverflowError) as exc:
        raise ValueError(f"{name} must be convertible to float64") from exc


def _vector(value, size, name, allow_infinity=False):
    value = as_float64_exact(value, name)
    if value.shape != (size,):
        raise ValueError(f"{name} must have shape ({size},)")
    if np.any(np.isnan(value)) or (
        not allow_infinity and not np.all(np.isfinite(value))
    ):
        raise ValueError(f"{name} contains invalid nonfinite values")
    return value


def _matrix(value, shape, name, preserve_float_duplicates=False):
    if sparse.issparse(value):
        if np.issubdtype(value.dtype, np.complexfloating):
            raise ValueError(f"{name} must be real")
        stored = value.data if value.format == "csr" else value.tocoo(copy=False).data
        _check_exact_integers(stored, name)
        if preserve_float_duplicates and value.dtype.kind == "f" and value.format != "csr":
            # Linear validation can recover exact residuals from finite stored
            # entries even when a duplicate sum overflows. Keep those entries
            # separate until _linear_residual has made its precision decision.
            value = value.tocoo(copy=True)
            value.data = np.asarray(value.data, dtype=np.float64)
        elif (value.format != "csr" or
                (value.dtype.kind in "iu" and not value.has_canonical_format)):
            # Integer duplicate sums must be exact before floating arithmetic;
            # converting first can either overflow or lose cancelling terms.
            value = prepare_float64_coefficient(value, name)
        finite = np.all(np.isfinite(value.data))
    else:
        value = normalize_arraylike(value)
        if isinstance(value, (list, tuple)):
            _check_exact_integers(value, name)
        value = np.asarray(value)
        if not np.isrealobj(value):
            raise ValueError(f"{name} must be real")
        _check_exact_integers(value, name)
        if value.dtype.kind not in "biuf" or value.dtype.itemsize > 8:
            value = as_float64_exact(value, name)
        # Ordinary numeric matrices need no full float64 copy: multiplication
        # by the float64 candidate already selects float64 arithmetic.
        finite = np.all(np.isfinite(value))
    if value.shape != shape:
        raise ValueError(f"{name} must have shape {shape}")
    if not finite:
        raise ValueError(f"{name} must be finite")
    return value


def _round_residual_up(numerator, denominator):
    """Represent a nonnegative exact residual without rounding it downward."""
    try:
        value = numerator / denominator
    except OverflowError:
        return np.inf
    if np.isfinite(value):
        rounded_numerator, rounded_denominator = value.as_integer_ratio()
        if rounded_numerator * denominator < numerator * rounded_denominator:
            # Moving to infinity or the smallest subnormal is intentional.
            with np.errstate(over="ignore", under="ignore"):
                value = np.nextafter(value, np.inf)
    return value


def _difference_violation(left, right, tolerance, *, absolute=False):
    """Check a single subtraction exactly when it rounds onto the tolerance."""
    with np.errstate(over="ignore", invalid="ignore"):
        difference = left - right
        violation = np.abs(difference) if absolute else np.maximum(difference, 0.0)
    # A correctly rounded subtraction cannot cross a representable tolerance;
    # only equality with that tolerance can hide which side the exact value is
    # on. Equal operands need no fallback, including at zero tolerance. Infinite
    # continuous bounds do not impose a finite distance to check exactly.
    threshold_distance = violation if absolute else difference
    ambiguous = ((threshold_distance == tolerance) & (left != right)
                 & np.isfinite(left) & np.isfinite(right))
    for index in np.flatnonzero(ambiguous):
        left_numerator, left_denominator = float(left[index]).as_integer_ratio()
        right_numerator, right_denominator = float(right[index]).as_integer_ratio()
        denominator = max(left_denominator, right_denominator)
        numerator = (left_numerator * (denominator // left_denominator)
                     - right_numerator * (denominator // right_denominator))
        numerator = abs(numerator) if absolute else max(numerator, 0)
        violation[index] = _round_residual_up(numerator, denominator)
    return violation


def _linear_residual(original, prepared, x, rhs, tolerance, equality):
    """Use exact dyadic sums when rounding could change row feasibility.

    The ordinary path is a vectorized float64 product. A conservative forward
    error bound also covers sparse duplicate summation. Ambiguous rows use the
    original stored entries, so canonicalization cannot hide cancelling terms.
    No sparse matrix is densified, and no source buffers are changed.
    """
    if not len(rhs):
        return 0.0
    with np.errstate(over="ignore", invalid="ignore", under="ignore"):
        residual = np.asarray(prepared @ x - rhs, dtype=np.float64)
        violations = np.abs(residual) if equality else np.maximum(residual, 0.0)

    if sparse.issparse(original):
        if original.format == "csr":
            stored = original.data
            row_sizes = np.diff(original.indptr)
            coo = None
        else:
            coo = original.tocoo(copy=False)
            stored = coo.data
            row_sizes = np.bincount(coo.row, minlength=len(rhs))
        terms = int(np.max(row_sizes, initial=0))
    else:
        original = np.asarray(original)
        stored = original
        terms = original.shape[1]

    # Each row has at most `terms` products and additions, plus subtraction
    # of rhs. The extra allowance covers duplicate canonicalization and the
    # bound's own rounding. Upward rounding keeps subnormal bounds nonzero.
    largest_coefficient = max(
        abs(float(np.min(stored, initial=0))),
        abs(float(np.max(stored, initial=0))),
    )
    largest_x = float(np.max(np.abs(x), initial=0.0))
    operations = 4 * terms + 8
    unit_error = np.finfo(np.float64).eps / 2
    error_factor = operations * unit_error
    with np.errstate(over="ignore", invalid="ignore", under="ignore"):
        magnitude = np.nextafter(float(terms) * largest_coefficient, np.inf)
        magnitude = np.nextafter(magnitude * largest_x, np.inf)
        magnitude = np.nextafter(magnitude + np.abs(rhs), np.inf)
        if error_factor >= 0.5:
            error_bound = np.full(len(rhs), np.inf)
        else:
            gamma = np.nextafter(error_factor / (1 - error_factor), np.inf)
            error_bound = np.nextafter(gamma * magnitude, np.inf)
            error_bound = np.nextafter(
                error_bound + operations * np.nextafter(0.0, 1.0), np.inf
            )
        ambiguous = (
            ~np.isfinite(residual) | ~np.isfinite(error_bound)
            | (np.abs(violations - tolerance) <= error_bound)
        )
    rows = np.flatnonzero(ambiguous)
    if not len(rows):
        return float(np.max(violations, initial=0.0))

    coordinates = [float(value).as_integer_ratio() for value in x]
    # Sort COO entries by row only when an exact check is actually needed.
    # Unlike conversion to CSR, this retains duplicate entries separately.
    if sparse.issparse(original) and coo is not None:
        order = np.argsort(coo.row, kind="stable")
        row_starts = np.concatenate(([0], np.cumsum(row_sizes)))

    for row in rows:
        if not sparse.issparse(original):
            entries = enumerate(original[row])
        elif coo is None:
            start, stop = original.indptr[row:row + 2]
            entries = zip(original.indices[start:stop], original.data[start:stop])
        else:
            positions = order[row_starts[row]:row_starts[row + 1]]
            entries = zip(coo.col[positions], coo.data[positions])

        rhs_numerator, denominator = float(rhs[row]).as_integer_ratio()
        numerator = -rhs_numerator
        for column, coefficient in entries:
            coefficient_numerator, coefficient_denominator = float(coefficient).as_integer_ratio()
            x_numerator, x_denominator = coordinates[column]
            product_numerator = coefficient_numerator * x_numerator
            product_denominator = coefficient_denominator * x_denominator
            # Binary floating values have power-of-two denominators, so their
            # common denominator is the larger one; all operations are exact.
            if product_denominator > denominator:
                numerator *= product_denominator // denominator
                denominator = product_denominator
            numerator += product_numerator * (denominator // product_denominator)
        numerator = abs(numerator) if equality else max(numerator, 0)
        # Round diagnostics upward: a residual just above tolerance must not
        # round onto it, including below the subnormal range.
        violations[row] = _round_residual_up(numerator, denominator)
    return float(np.max(violations, initial=0.0))


def validate_candidate(problem, candidate, feasibility_tol=1e-5):
    """Validate a candidate without solver caches, clipping, or model mutation.

    Compute the original quadratic objective in CPU float64, preserving sparse
    matrices. Binary variables occupy the first ``n_binary_vars`` coordinates
    and must lie within tolerance of one of their original bounds. QUBO uses
    endpoints 0 and 1. A malformed model raises ``ValueError``; an absent,
    malformed, nonfinite, or infeasible candidate returns invalid diagnostics.
    """
    tolerance = _tolerance(feasibility_tol, "feasibility_tol")
    if candidate is None:
        return CandidateValidation(False, reason="missing_candidate")
    try:
        x = as_float64_exact(candidate, "candidate")
    except (TypeError, ValueError, OverflowError):
        return CandidateValidation(False, reason="invalid_candidate")

    nvar = problem.nvar
    if (
        isinstance(nvar, (bool, np.bool_))
        or not isinstance(nvar, (int, np.integer))
        or nvar < 0
    ):
        raise ValueError("nvar must be a nonnegative integer")
    if x.shape != (nvar,):
        return CandidateValidation(False, reason="invalid_shape")
    if not np.all(np.isfinite(x)):
        return CandidateValidation(False, reason="nonfinite_candidate")

    Q = _matrix(problem.Q, (nvar, nvar), "Q")
    if isinstance(problem, QUBO):
        w = np.zeros(nvar, dtype=np.float64)
        lower = np.zeros(nvar, dtype=np.float64)
        upper = np.ones(nvar, dtype=np.float64)
        n_binary = nvar
    else:
        w = _vector(problem.w, nvar, "w")
        lower = _vector(problem.bounds[0], nvar, "lower bounds", True)
        upper = _vector(problem.bounds[1], nvar, "upper bounds", True)
        n_binary = getattr(problem, "n_binary_vars", 0)
    if (
        np.any(lower > upper)
        or np.any(np.isposinf(lower))
        or np.any(np.isneginf(upper))
    ):
        raise ValueError("problem has inconsistent bounds")
    if (
        isinstance(n_binary, (bool, np.bool_))
        or not isinstance(n_binary, (int, np.integer))
        or not 0 <= n_binary <= nvar
    ):
        raise ValueError("n_binary_vars must be an integer between zero and nvar")
    if not np.all(np.isfinite(lower[:n_binary])) or not np.all(
        np.isfinite(upper[:n_binary])
    ):
        raise ValueError("binary endpoints must be finite")

    bound_residual = float(
        max(np.max(_difference_violation(lower, x, tolerance), initial=0.0),
            np.max(_difference_violation(x, upper, tolerance), initial=0.0))
    )
    binary_residual = float(
        np.max(
            np.minimum(
                _difference_violation(x[:n_binary], lower[:n_binary], tolerance, absolute=True),
                _difference_violation(x[:n_binary], upper[:n_binary], tolerance, absolute=True),
            ),
            initial=0.0,
        )
    )
    inequality_residual = 0.0
    equality_residual = 0.0
    if hasattr(problem, "A"):
        b = as_float64_exact(problem.b, "b")
        if b.ndim != 1:
            raise ValueError("b must be one-dimensional")
        A = _matrix(problem.A, (len(b), nvar), "A", preserve_float_duplicates=True)
        b = _vector(b, len(b), "b")
        inequality_residual = _linear_residual(problem.A, A, x, b, tolerance, False)
    if hasattr(problem, "C"):
        d = as_float64_exact(problem.d, "d")
        if d.ndim != 1:
            raise ValueError("d must be one-dimensional")
        C = _matrix(problem.C, (len(d), nvar), "C", preserve_float_duplicates=True)
        d = _vector(d, len(d), "d")
        equality_residual = _linear_residual(problem.C, C, x, d, tolerance, True)

    with np.errstate(over="ignore", invalid="ignore"):
        # Match the original model's half-scaled ordering. Q @ x can overflow
        # even when (0.5 * x) @ Q @ x is finite and representable.
        objective = float((0.5 * x) @ Q @ x + w @ x)
    residuals = (
        bound_residual,
        binary_residual,
        inequality_residual,
        equality_residual,
    )
    finite = np.isfinite(objective) and np.all(np.isfinite(residuals))
    valid = bool(finite and max(residuals) <= tolerance)
    return CandidateValidation(
        valid=valid,
        objective=objective if np.isfinite(objective) else None,
        reason=None if valid else ("infeasible" if finite else "nonfinite_evaluation"),
        max_bound_violation=bound_residual,
        max_binary_violation=binary_residual,
        max_inequality_violation=inequality_residual,
        max_equality_violation=equality_residual,
    )
