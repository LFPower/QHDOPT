import numpy as np
import jax
import jax.numpy as jnp
from attr import field
from attrs import define
from phisolve.problems.lcqp import LCQP
from phisolve.problems.problem import copy_mutable_data, copy_model_data
import scipy as sp
from phisolve.utils.jax_utils import to_dense_mat
from phisolve.utils.precision import (
    average_prepared_quadratic_blocks, prepare_float64_coefficient,
    check_jax_integer_precision, normalize_arraylike, promote_prepared_quadratic,
)


@define
class MIQP(LCQP):
    """
    Class to define Mixed-Integer quadratic programs:
    minimize f(x) = 0.5 * x.T @ Q @ x + w.T @ x
    subject to: Ax <= b,
                Cx = d,
                l_i <= x_i <= u_i.
                for all i in I, x_i is in {l_i, u_i}

    Parameters
    ----------
    n_binary_vars
    """

    n_binary_vars: int = field()

    @n_binary_vars.default
    def n_binary_vars_default(self):
        return 0

    def to_dict(self):
        return dict(
            Q=self.Q,
            w=self.w,
            bounds=self.bounds,
            A=self.A,
            b=self.b,
            C=self.C,
            d=self.d,
            n_binary_vars=self.n_binary_vars,
        )

    def with_new_bounds(self, bounds):
        kwargs = self.to_dict()
        kwargs['bounds'] = bounds
        return MIQP(**kwargs)

    def clone(self):
        """Return an independent model; immutable JAX values may be shared."""
        kwargs = copy_model_data(self.to_dict())
        return MIQP(**kwargs)

    def to_dense(self):
        kwargs = self.to_dict()
        kwargs["Q"] = to_dense_mat(kwargs["Q"])
        kwargs["A"] = to_dense_mat(kwargs["A"])
        kwargs["C"] = to_dense_mat(kwargs["C"])
        return MIQP(**kwargs)

    def max_vios(self, x):
        """Maximum linear, bound, or binary-endpoint residual."""
        linear_residual = super().max_vios(x)
        if self.n_binary_vars == 0:
            return linear_residual
        xp, operands = self._residual_operands(
            x, force_jax=isinstance(linear_residual, (jax.Array, jax.core.Tracer)))
        binary_x = operands["x"][:self.n_binary_vars]
        endpoint_distance = xp.minimum(
            xp.abs(binary_x - operands["lower"][:self.n_binary_vars]),
            xp.abs(binary_x - operands["upper"][:self.n_binary_vars]),
        )
        return xp.maximum(linear_residual, xp.max(endpoint_distance, initial=0.0))

    def max_vios_batch(self, X):
        """Batched residuals including binary endpoints; supports JAX tracing."""
        linear_residuals = super().max_vios_batch(X)
        if self.n_binary_vars == 0:
            return linear_residuals
        xp, operands = self._residual_operands(
            X, force_jax=isinstance(linear_residuals, (jax.Array, jax.core.Tracer)))
        X = xp.atleast_2d(operands["x"])
        binary_x = X[:, :self.n_binary_vars]
        endpoint_distance = xp.minimum(
            xp.abs(binary_x - operands["lower"][:self.n_binary_vars]),
            xp.abs(binary_x - operands["upper"][:self.n_binary_vars]),
        )
        return xp.maximum(
            linear_residuals, xp.max(endpoint_distance, axis=1, initial=0.0)
        )

    def fix_binary_values(self, binary_values):
        """Reduce fixed binary coordinates without sharing mutable model data.

        The returned objective omits the fixed-coordinate constant
        ``0.5 * z @ Q_bb @ z + w_b @ z``. Final solution reporting should
        evaluate the reconstructed candidate on the original model.
        """
        # Prepare before sparse slicing/canonicalization or integer products.
        # Keep the original values for precision checks at mixed JAX boundaries.
        original_fixed = binary_values
        binary_values = prepare_float64_coefficient(binary_values, "binary_values", True)
        # Inspect the prepared array's static shape: NumPy cannot discover the
        # shape of a Python container of tracers without trying to read them.
        if binary_values.shape != (self.n_binary_vars,):
            raise ValueError("binary_values must contain one value per binary variable")

        def prepared_matrix(matrix, name):
            # The solver prepares these once for all support groups. Reuse
            # safe storage here, then copy only the reduced mutable blocks.
            if (sp.sparse.issparse(matrix) and matrix.format in {"csr", "csc"}
                    and matrix.dtype == np.float64 and matrix.has_canonical_format):
                return matrix
            return prepare_float64_coefficient(matrix, name, True)

        Q = promote_prepared_quadratic(prepared_matrix(self.Q, "Q"))
        A = prepared_matrix(self.A, "A")
        C = prepared_matrix(self.C, "C")
        w = prepare_float64_coefficient(self.w, "w", True)
        b = prepare_float64_coefficient(self.b, "b", True)
        d = prepare_float64_coefficient(self.d, "d", True)
        lower = prepare_float64_coefficient(self.bounds[0], "lower bounds", True)
        upper = prepare_float64_coefficient(self.bounds[1], "upper bounds", True)

        def original_subset(value, key, prepared):
            value = normalize_arraylike(value)
            if isinstance(value, (jax.Array, jax.core.Tracer)):
                # Preparation has already checked the whole JAX value before
                # converting its integers. Slicing the original again under
                # jit would turn a checked captured constant into an apparent
                # unchecked integer tracer. Carry the checked floating slice.
                return prepared[key]
            # Sparse integer provenance applies to the canonical subset too;
            # slicing raw COO storage before preparation would be unsafe.
            if sp.sparse.issparse(value):
                return value
            if isinstance(value, (list, tuple)):
                value = np.asarray(value, dtype=object)
            return value[key]

        def update_vector(matrix, vector, original_matrix, original_vector, name, sign,
                          transpose_block=None, original_transpose_block=None):
            if not matrix.shape[0] or not matrix.shape[1]:
                return copy_mutable_data(vector)
            fixed = binary_values
            jax_types = (jax.Array, jax.core.Tracer)
            mixed_jax = any(isinstance(value, jax_types)
                            for value in (matrix, transpose_block, vector, fixed))
            if mixed_jax:
                # All host operands in this arithmetic group use the actual
                # execution dtype. Check original integer values first; pure
                # host groups, copied bounds, and unused matrix blocks stay
                # float64. Arithmetic results may round normally afterward.
                dtype = np.float64 if jax.config.x64_enabled else np.float32

                # Check each original cross block before averaging: checking
                # only the average could hide unsupported integer operands.
                check_jax_integer_precision(original_matrix, matrix, name)
                if transpose_block is not None:
                    check_jax_integer_precision(original_transpose_block, transpose_block, name)
                check_jax_integer_precision(
                    original_vector, vector, {"Q": "w", "A": "b", "C": "d"}[name]
                )
                check_jax_integer_precision(original_fixed, fixed, "binary_values")
            if transpose_block is not None:
                # Average in prepared precision before any host-to-JAX
                # narrowing, so canceling skew terms cannot overflow first.
                matrix = average_prepared_quadratic_blocks(matrix, transpose_block)
            if mixed_jax:
                matrix, vector, fixed = (
                    value if isinstance(value, jax_types) else value.astype(dtype, copy=False)
                    for value in (matrix, vector, fixed)
                )
            return vector + sign * (matrix @ fixed)

        free = slice(self.n_binary_vars, None)
        fixed_columns = slice(None, self.n_binary_vars)
        Q_p = copy_mutable_data(Q[self.n_binary_vars :, self.n_binary_vars :])
        w_p = update_vector(
            Q[free, fixed_columns], w[free],
            original_subset(self.Q, (free, fixed_columns), Q), original_subset(self.w, free, w), "Q", 1,
            transpose_block=Q[fixed_columns, free].T,
            original_transpose_block=original_subset(self.Q, (fixed_columns, free), Q).T,
        )
        A_p = copy_mutable_data(A[:, self.n_binary_vars :])
        b_p = update_vector(
            A[:, fixed_columns], b,
            original_subset(self.A, (slice(None), fixed_columns), A), self.b, "A", -1,
        )
        C_p = copy_mutable_data(C[:, self.n_binary_vars :])
        d_p = update_vector(
            C[:, fixed_columns], d,
            original_subset(self.C, (slice(None), fixed_columns), C), self.d, "C", -1,
        )
        l_p = copy_mutable_data(lower[self.n_binary_vars :])
        u_p = copy_mutable_data(upper[self.n_binary_vars :])
        return LCQP(Q=Q_p, w=w_p, A=A_p, b=b_p, C=C_p, d=d_p, bounds=(l_p, u_p))
