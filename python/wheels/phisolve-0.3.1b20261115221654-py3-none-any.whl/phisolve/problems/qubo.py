from typing import List, Tuple

import numpy as np
from attr import field
from attrs import define
from numpy import ndarray

from phisolve.problems.problem import Problem, copy_mutable_data
from phisolve.problems.boxqp import BoxQP
from phisolve.utils.jax_utils import frobenius_norm, to_dense_mat
from phisolve.utils.precision import (
    average_prepared_quadratic_blocks, prepare_float64_coefficient,
    promote_prepared_quadratic,
)


@define
class QUBO(Problem):
    """
    Class to define quadratic unconstrained binary optimization programs:
    minimize f(x) = 1/2 * x.T @ Q @ x
    subject to: x_i ∈ {0, 1}.
    (Note the coefficient 1/2 in f(x))

    Parameters
    ----------
    Q : np.ndarray
    nvar : int
    """

    Q: np.ndarray = field()
    nvar: int = field()

    @nvar.default
    def nvar_default(self):
        return self.Q.shape[0]

    @nvar.validator
    def nvar_validate(instance, field, val):
        if val != instance.Q.shape[0]:
            raise ValueError("dimensions don't match.")

    def to_dict(self):
        return dict(
            Q=self.Q,
            w=np.zeros(self.Q.shape[0]),
        )

    def clone(self):
        """Return an independent model; immutable JAX values may be shared."""
        return QUBO(copy_mutable_data(self.Q))
    
    def to_dense(self):
        return QUBO(Q=copy_mutable_data(to_dense_mat(self.Q)))

    def obj(self, x):
        return 0.5 * x @ self.Q @ x

    def grad(self, x):
        """Differentiate the scalar quadratic on its continuous relaxation."""
        Q = prepare_float64_coefficient(self.Q, "Q", preserve_jax=True)
        Q = promote_prepared_quadratic(Q)
        Q = average_prepared_quadratic_blocks(Q, Q.T)
        return Q @ x

    def with_new_bounds(self, bounds):
        pass

    def bounds(self):
        pass

    def affine_trans(self, x):
        return x

    def relax_to_BoxQP(self):
        new_Q = self.Q
        w = np.zeros(self.nvar)
        return BoxQP(new_Q, w)

    def feasibility_test(self, x, weak=False, feasibility_tol=1e-5):
        """Check binary membership; ``weak=True`` explicitly checks its relaxation."""
        from phisolve.validation import validate_candidate

        problem = self.relax_to_BoxQP() if weak else self
        return validate_candidate(problem, x, feasibility_tol=feasibility_tol).valid

    def first_der_test(self, x, *args):
        """
        First-order residual for the continuous [0, 1] box relaxation.
        violation of the KKT condition = ||x - P(x - nabla_x f(x), l, u)||_2
        A zero residual does not establish binary feasibility or optimality.
        The residual norm uses scaled arithmetic to avoid squaring overflow
        or underflow when the norm is representable.
        Reference: Section 17.4, pp520, Nocedal & Wright
        """
        z = np.clip(x - self.grad(x), 0, 1)
        return frobenius_norm(x - z)
