from typing import List, Tuple, Union

import jax
import jax.numpy as jnp
import numpy as np
from attr import field
from attrs import define
from numpy import ndarray
import scipy as sp

from phisolve.problems.problem import Problem, copy_model_data
from phisolve.utils.jax_utils import frobenius_norm, to_dense_mat
from phisolve.utils.precision import (
    average_prepared_quadratic_blocks, prepare_float64_coefficient,
    check_jax_integer_precision, prepare_jax_coefficient, promote_prepared_quadratic,
)


@define
class BoxQP(Problem):
    """
    Class to define box-constrained quadratic programs:
    minimize f(x) = 0.5 * x.T @ Q @ x + w.T @ x
    subject to: l_i <= x_i <= u_i.

    Parameters
    ----------
    Q : Union[np.ndarray, sp.sparse.spmatrix]
    w : np.ndarray
    bounds: Tuple
    nvar : int
    """

    Q: Union[np.ndarray, sp.sparse.spmatrix] = field()
    w: np.ndarray = field()
    bounds: Tuple[ndarray, ndarray] = field()
    nvar: int = field()

    @bounds.default
    def bounds_default(self):
        return np.zeros(self.w.shape[0]), np.ones(self.w.shape[0])

    @nvar.default
    def nvar_default(self):
        return self.w.shape[0]

    @nvar.validator
    def nvar_validate(instance, field, val):
        if val != instance.Q.shape[0] or instance.Q.shape[0] != instance.w.shape[0]:
            raise ValueError("dimensions don't match.")

    @property
    def Q_norm(self):
        """Stable Frobenius norm, preserving sparse coefficient storage."""
        return frobenius_norm(self.Q)

    @property
    def w_norm(self):
        """Stable Euclidean norm of the linear coefficients."""
        return frobenius_norm(self.w)

    def to_dict(self):
        return dict(
            Q=self.Q,
            w=self.w,
            bounds=self.bounds,
        )

    def with_new_bounds(self, bounds):
        kwargs = self.to_dict()
        kwargs['bounds'] = bounds
        return BoxQP(**kwargs)

    def clone(self):
        """Return an independent model; immutable JAX values may be shared."""
        kwargs = copy_model_data(self.to_dict())
        return BoxQP(**kwargs)
    
    def to_dense(self):
        kwargs = self.to_dict()
        kwargs["Q"] = to_dense_mat(kwargs["Q"])
        return BoxQP(**kwargs)

    def _objective_operands(self, x, *, force_jax=False):
        """Prepare original operands before any integer product or conversion.

        Host evaluation uses float64 and keeps sparse matrices sparse. Mixed
        JAX evaluation checks original integer values against the caller's
        execution precision before placement; floating tracers stay traceable.
        Preparation is local so mutable model data is current on every call.
        """
        originals = (self.Q, self.w, x)
        names = ("Q", "w", "x")
        prepared = tuple(prepare_float64_coefficient(value, name, preserve_jax=True)
                         for value, name in zip(originals, names))
        use_jax = force_jax or any(isinstance(value, (jax.Array, jax.core.Tracer))
                                   for value in prepared)
        if use_jax:
            for original, value, name in zip(originals, prepared, names):
                check_jax_integer_precision(original, value, name)
            prepared = tuple(jnp.asarray(to_dense_mat(value)) for value in prepared)
        return prepared

    def obj(self, x):
        """Evaluate the quadratic with prepared floating operands."""
        Q, w, x = self._objective_operands(x)
        return (0.5 * x) @ Q @ x + w @ x

    def prepare_jax(self):
        """Prepare current operands, including changes to mutable host arrays.

        Return per-call arrays so traced evaluation never relies on persistent
        caches. Keep the concrete attributes for callers that prepare explicitly,
        but do not retain tracers on the model during JIT compilation.
        """
        Q = jnp.asarray(to_dense_mat(prepare_jax_coefficient(self.Q, "Q")))
        w = jnp.asarray(prepare_jax_coefficient(self.w, "w"))
        bounds = tuple(jnp.asarray(prepare_jax_coefficient(value, "bounds"))
                       for value in self.bounds)
        if not any(isinstance(value, jax.core.Tracer) for value in (Q, w, *bounds)):
            self.Q_j, self.w_j, self.bounds_j = Q, w, bounds
        return Q, w, bounds

    def obj_batch(self, X):
        """Vectorized objective evaluation.

        Accepts X shaped (n_samples, nvar). Returns array of objectives.
        Host inputs use float64; JAX operands retain the caller's execution
        precision. Integer inputs are checked before conversion and products.
        """
        Q, w, X = self._objective_operands(X)
        xp = jnp if isinstance(X, (jax.Array, jax.core.Tracer)) else np
        # Match scalar obj's half-first ordering, avoiding an overflowing
        # unscaled product when the half-scaled objective is representable.
        return xp.sum(((0.5 * X) @ Q) * X, axis=1) + X @ w

    def obj_batch_jax_vmap(self, X):
        """JITed + vmapped objective evaluation for JAX arrays."""
        Q, w, X = self._objective_operands(X, force_jax=True)
        @jax.jit
        @jax.vmap
        def _obj(x):
            return 0.5 * x @ Q @ x + w @ x
        return _obj(X)

    def grad(self, x):
        """Differentiate the stated quadratic without changing its storage."""
        Q = prepare_float64_coefficient(self.Q, "Q", preserve_jax=True)
        Q = promote_prepared_quadratic(Q)
        Q = average_prepared_quadratic_blocks(Q, Q.T)
        w = prepare_float64_coefficient(self.w, "w", preserve_jax=True)
        return Q @ x + w

    def affine_trans(self, x):
        # Halve first so finite same-sign endpoints cannot overflow the sum.
        k = self.bounds[0] / 2 - self.bounds[1] / 2
        t = self.bounds[0] / 2 + self.bounds[1] / 2

        return k*x + t
    
    def _residual_operands(self, x, *, linear=False, force_jax=False):
        """Prepare only operands used by violation diagnostics before arithmetic.

        Host arithmetic keeps sparse matrices sparse and checks float64 integer
        representation. JAX groups check original integers before execution
        conversion, preserving floating tracing and current mutable model data.
        Objective coefficients do not participate in these residuals.
        """
        originals = {"x": x, "lower": self.bounds[0], "upper": self.bounds[1]}
        if linear:
            originals.update((name, getattr(self, name)) for name in ("A", "b", "C", "d"))
        prepared = {name: prepare_float64_coefficient(value, name, preserve_jax=True)
                    for name, value in originals.items()}
        use_jax = force_jax or any(isinstance(value, (jax.Array, jax.core.Tracer))
                                   for value in prepared.values())
        if use_jax:
            for name, value in prepared.items():
                check_jax_integer_precision(originals[name], value, name)
            prepared = {name: jnp.asarray(to_dense_mat(value))
                        for name, value in prepared.items()}
        return (jnp if use_jax else np), prepared

    def vios(self, x):
        """Lower/upper residuals with operands promoted before subtraction."""
        xp, operands = self._residual_operands(x)
        x = operands["x"]
        return (
            xp.maximum(0, operands["lower"] - x),
            xp.maximum(0, x - operands["upper"]),
        )
    
    def max_vios(self, x):
        vio_lb, vio_ub = self.vios(x)
        xp = jnp if any(isinstance(value, (jax.Array, jax.core.Tracer))
                        for value in (vio_lb, vio_ub)) else np
        vio = xp.concatenate((vio_lb, vio_ub))
        return xp.max(vio, initial=0.0)

    def max_vios_batch(self, X):
        """Vectorized max-violation per sample. X shape (n_samples, nvar)."""
        xp, operands = self._residual_operands(X)
        X = xp.atleast_2d(operands["x"])
        vio_lb = xp.maximum(0, operands["lower"] - X)
        vio_ub = xp.maximum(0, X - operands["upper"])
        vio = xp.concatenate((vio_lb, vio_ub), axis=1)
        return xp.max(vio, axis=1, initial=0.0)

    def calc_Q_w_affine(self):
        lower = prepare_float64_coefficient(self.bounds[0], "lower bounds", True)
        upper = prepare_float64_coefficient(self.bounds[1], "upper bounds", True)
        Q = prepare_float64_coefficient(self.Q, "Q", True)
        w = prepare_float64_coefficient(self.w, "w", True)
        # The quadratic form depends only on the symmetric part. The model
        # gate accepts approximate symmetry, so both the affine linear term
        # and QIHD's matrix-based force must use that same working Hessian.
        # Prepare first to preserve integer checks and sparse duplicate sums.
        Q = promote_prepared_quadratic(Q)
        Q = average_prepared_quadratic_blocks(Q, Q.T)
        k = lower / 2 - upper / 2
        t = lower / 2 + upper / 2

        if sp.sparse.issparse(Q):
            diag_k = sp.sparse.spdiags(k, 0, self.nvar, self.nvar)
            Q_affine = diag_k @ Q @ diag_k
            kQ = diag_k @ Q
            w_affine = kQ @ t + k * w
        else:
            kQ = (Q.T * k).T
            Q_affine = kQ * k
            w_affine = kQ @ t + k * w
        return Q_affine, w_affine

    def feasibility_test(self, x, feasibility_tol=1e-5):
        """Validate this model's complete domain, including subclass constraints."""
        from phisolve.validation import validate_candidate

        return validate_candidate(self, x, feasibility_tol=feasibility_tol).valid

    def first_der_test(self, x, *args):
        """
        First-order residual for the continuous box relaxation.
        violation of the KKT condition = ||x - P(x - nabla_x f(x), l, u)||_2
        A zero residual establishes box stationarity, not optimality or
        satisfaction of any additional affine or discrete constraints.
        The residual norm uses scaled arithmetic to avoid squaring overflow
        or underflow when the norm is representable.
        Reference: Section 17.4, pp520, Nocedal & Wright
        """
        z = np.clip(x - self.grad(x), self.bounds[0], self.bounds[1])
        return frobenius_norm(x - z)

    def decode(self, binary_values):
        binary_values = np.array(binary_values)
        return np.where(binary_values > 0.5, 1, 0)
