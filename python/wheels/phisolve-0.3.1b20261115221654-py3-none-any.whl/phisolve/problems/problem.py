import abc

import numpy as np
import scipy.sparse as sparse

from phisolve.utils.precision import normalize_arraylike, prepare_float64_coefficient


def copy_mutable_data(value):
    """Copy model-owned mutable buffers while sharing immutable JAX values.

    Reduced problems use this after slicing, so they copy only their reduced
    blocks rather than copying an entire original model for every candidate.
    JAX arrays and tracers are immutable and remain safe to share under vmap.
    """
    if isinstance(value, np.ndarray):
        copied = value.copy()
        if value.dtype.kind == "O":
            # ndarray.copy() copies object references, not the mutable arrays
            # or containers they point at (for example, an object bounds pair).
            for index in np.ndindex(value.shape):
                copied[index] = copy_mutable_data(value[index])
        elif value.dtype.hasobject:
            # Structured arrays can contain object-valued fields as well.
            for name in value.dtype.names:
                if value.dtype[name].hasobject:
                    copied[name] = copy_mutable_data(value[name])
        return copied
    if sparse.issparse(value):
        return value.copy()
    if isinstance(value, tuple):
        return tuple(copy_mutable_data(item) for item in value)
    if isinstance(value, list):
        return [copy_mutable_data(item) for item in value]
    if isinstance(value, dict):
        return {key: copy_mutable_data(item) for key, item in value.items()}
    # Buffer and __array__ wrappers can expose caller-owned mutable storage.
    # Normalize without dtype promotion, then copy the exposed array (including
    # nested object contents). Immutable JAX values and tracers stay unchanged.
    normalized = normalize_arraylike(value)
    if normalized is not value:
        return copy_mutable_data(normalized)
    return value


def copy_model_data(data):
    """Copy constructor arguments and expose sequence coefficient vectors.

    Constructors inspect vector shapes before numerical preparation. Box each
    scalar separately to retain integer provenance and avoid materializing JAX
    tracers; normal NumPy promotion could round a mixed integer/float sequence.
    Other containers, including the outer bounds pair, retain their structure.
    """
    copied = copy_mutable_data(data)
    for name in ("w", "b", "d"):
        value = copied.get(name)
        if isinstance(value, (list, tuple)):
            vector = np.empty(len(value), dtype=object)
            for index, item in enumerate(value):
                if isinstance(item, (list, tuple)) or getattr(item, "ndim", 0) != 0:
                    raise ValueError(f"{name} must be a vector of scalar values")
                vector[index] = item
            copied[name] = vector
    return copied


class Problem(metaclass=abc.ABCMeta):
    @abc.abstractmethod
    def obj(self, x):
        pass

    @abc.abstractmethod
    def clone(self):
        pass

    @abc.abstractmethod
    def grad(self, x):
        pass

    @abc.abstractmethod
    def with_new_bounds(self, bounds):
        pass

    @property
    @abc.abstractmethod
    def bounds(self):
        pass

    @property
    @abc.abstractmethod
    def nvar(self):
        pass

    def with_trust_region(self, x, scaling_factor=1):
        """Intersect the original domain with a box of radius 1/scaling_factor.

        The returned independent model uses original coordinates and retains
        its objective and affine rows. MIQP endpoint coordinates keep only
        their original endpoints inside the region; a singleton is fixed.
        Empty intersections and invalid centers/scales raise ValueError.
        This is a host-side model transformation, not a traced JAX operation.
        """
        if isinstance(scaling_factor, (bool, np.bool_)):
            raise ValueError("scaling_factor must be a finite positive scalar")
        factor = prepare_float64_coefficient(scaling_factor, "scaling_factor")
        if factor.shape != () or not np.isfinite(factor) or factor <= 0:
            raise ValueError("scaling_factor must be a finite positive scalar")
        with np.errstate(over="ignore", under="ignore"):
            delta = 1.0 / factor
        if not np.isfinite(delta) or delta <= 0:
            raise ValueError("scaling_factor must give a finite positive radius")
        center = prepare_float64_coefficient(x, "trust-region center")
        if center.shape != (self.nvar,) or not np.all(np.isfinite(center)):
            raise ValueError(f"trust-region center must be finite with shape ({self.nvar},)")
        try:
            lower, upper = self.bounds
        except (TypeError, ValueError) as error:
            raise TypeError("with_trust_region requires explicit box bounds") from error
        lower = prepare_float64_coefficient(lower, "lower bounds")
        upper = prepare_float64_coefficient(upper, "upper bounds")
        if (lower.shape != center.shape or upper.shape != center.shape
                or not np.all(lower <= upper) or np.any(lower == np.inf)
                or np.any(upper == -np.inf)):
            raise ValueError("invalid box bounds for trust region")
        with np.errstate(over="ignore"):
            new_lower = np.maximum(lower, center - delta)
            new_upper = np.minimum(upper, center + delta)
        if np.any(new_lower > new_upper):
            raise ValueError("trust region has an empty intersection with the box bounds")

        n_binary = getattr(self, "n_binary_vars", 0)
        if (isinstance(n_binary, (bool, np.bool_))
                or not isinstance(n_binary, (int, np.integer))
                or not 0 <= n_binary <= self.nvar):
            raise ValueError("n_binary_vars must be an integer between 0 and nvar")
        if n_binary:
            lo, hi = lower[:n_binary], upper[:n_binary]
            keep_lo = (lo >= new_lower[:n_binary]) & (lo <= new_upper[:n_binary])
            keep_hi = (hi >= new_lower[:n_binary]) & (hi <= new_upper[:n_binary])
            if np.any(~(keep_lo | keep_hi)):
                raise ValueError("trust region has an empty binary-endpoint domain")
            new_lower[:n_binary] = np.where(keep_lo, lo, hi)
            new_upper[:n_binary] = np.where(keep_hi, hi, lo)
        return self.clone().with_new_bounds((new_lower, new_upper))
