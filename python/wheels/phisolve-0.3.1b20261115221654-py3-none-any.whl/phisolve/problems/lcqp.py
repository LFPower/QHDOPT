import numpy as np
import jax
import jax.numpy as jnp
import scipy as sp
from attr import field
from attrs import define
from typing import Tuple
from phisolve.problems.boxqp import BoxQP
from phisolve.problems.problem import copy_model_data, copy_mutable_data
from phisolve.utils.jax_utils import inf_norm, mat_norm, to_dense_mat
from phisolve.utils.precision import prepare_float64_coefficient

@define
class LCQP(BoxQP):
    """
    Class to define linearly constrained quadratic programs:
    minimize f(x) = 0.5 * x.T @ Q @ x + w.T @ x
    subject to: Ax <= b, Cx = d, lb <= x <= ub

    Parameters
    ----------
    Q : np.ndarray
    w : np.ndarray
    A : np.ndarray
    b : np.ndarray
    C : np.ndarray
    d : np.ndarray
    bounds : Tuple[np.ndarray, np.ndarray]
    """

    A: np.ndarray = field()
    b: np.ndarray = field()
    C: np.ndarray = field()
    d: np.ndarray = field()
    ncon_ineq: int = field()
    ncon_eq: int = field()

    @A.default
    def A_default(self):
        return np.zeros((0, self.w.shape[0]))

    @b.default
    def b_default(self):
        return np.array([])

    @C.default
    def C_default(self):
        return np.zeros((0, self.w.shape[0]))

    @d.default
    def d_default(self):
        return np.array([])

    @property
    def A_norm(self):
        return mat_norm(self.A)

    @property
    def b_norm(self):
        return mat_norm(self.b)

    @property
    def C_norm(self):
        return mat_norm(self.C)

    @property
    def d_norm(self):
        return mat_norm(self.d)

    @ncon_ineq.default
    def ncon_ineq_default(self):
        return self.b.shape[0]

    @ncon_eq.default
    def ncon_eq_default(self):
        return self.d.shape[0]

    @property
    def A2(self):
        return self.A.T @ self.A

    @property
    def C2(self):
        return self.C.T @ self.C

    @A.validator
    def a_validator(instance, field, val):
        if val.shape[0] != instance.b.shape[0]:
            raise ValueError("A and b dimensions don't match")

    @C.validator
    def c_validator(instance, field, val):
        if val.shape[0] != instance.d.shape[0]:
            raise ValueError("C and d dimensions don't match")

    def with_new_bounds(self, bounds):
        return LCQP(Q=self.Q, w=self.w, A=self.A, b=self.b, C=self.C, d=self.d, bounds=bounds)

    def calc_A_b_C_d_affine(self):
        lower = prepare_float64_coefficient(self.bounds[0], "lower bounds", True)
        upper = prepare_float64_coefficient(self.bounds[1], "upper bounds", True)
        A = prepare_float64_coefficient(self.A, "A", True)
        b = prepare_float64_coefficient(self.b, "b", True)
        C = prepare_float64_coefficient(self.C, "C", True)
        d = prepare_float64_coefficient(self.d, "d", True)
        k = lower / 2 - upper / 2
        t = lower / 2 + upper / 2

        if sp.sparse.issparse(A):
            A_affine = A.multiply(k)
        else:
            A_affine = A * k
        b_affine = b - A @ t

        if sp.sparse.issparse(C):
            C_affine = C.multiply(k)
        else:
            C_affine = C * k
        d_affine = d - C @ t

        return A_affine, b_affine, C_affine, d_affine

    def violation(self, x):
        """Affine and box residuals; equality residuals retain their sign."""
        xp, operands = self._residual_operands(x, linear=True)
        x = operands["x"]
        return (
            xp.maximum(0, operands["A"] @ x - operands["b"]),
            operands["C"] @ x - operands["d"],
            xp.maximum(0, operands["lower"] - x),
            xp.maximum(0, x - operands["upper"]),
        )
    
    def vios(self, x):
        return self.violation(x)
    
    def max_vios(self, x):
        vio_ineq, vio_eq, vio_lb, vio_ub = self.vios(x)
        xp = jnp if any(isinstance(value, (jax.Array, jax.core.Tracer))
                        for value in (vio_ineq, vio_eq, vio_lb, vio_ub)) else np
        vio = xp.concatenate((vio_ineq, xp.abs(vio_eq), vio_lb, vio_ub))
        return xp.max(vio, initial=0.0)

    def to_dict(self):
        return dict(
            Q=self.Q,
            w=self.w,
            bounds=self.bounds,
            A=self.A,
            b=self.b,
            C=self.C,
            d=self.d,
        )

    def with_new_bounds(self, bounds):
        kwargs = self.to_dict()
        kwargs['bounds'] = bounds
        return LCQP(**kwargs)

    def clone(self):
        """Return an independent model; immutable JAX values may be shared."""
        kwargs = copy_model_data(self.to_dict())
        return LCQP(**kwargs)
    
    def to_dense(self):
        kwargs = self.to_dict()
        kwargs["Q"] = to_dense_mat(kwargs["Q"])
        kwargs["A"] = to_dense_mat(kwargs["A"])
        kwargs["C"] = to_dense_mat(kwargs["C"])
        return LCQP(**kwargs)

    def with_new_w(self, w):
        """Return an independent model of the same type with a new linear term.

        Inherited MIQP calls retain their binary count and endpoint domains.
        Mutable model data and the replacement vector are copied; immutable
        JAX arrays may be shared, following the model clone contract.
        """
        kwargs = self.to_dict()
        kwargs['w'] = w
        kwargs = copy_model_data(kwargs)
        if getattr(kwargs['w'], 'shape', None) != (self.nvar,):
            raise ValueError(f"w must have shape ({self.nvar},)")
        return type(self)(**kwargs)

    @staticmethod
    def inf_norm(mat):
        if mat.shape[0] == 0:
            return 0
        # return jnp.max((jnp.max(mat), -jnp.min(mat)))
        return jnp.linalg.norm(mat, ord=jnp.inf)

    def _penalty_coefficients(self):
        """Prepare a continuous equality-only model for host transformation."""
        if getattr(self, 'n_binary_vars', 0) != 0:
            raise ValueError("Penalty conversion requires continuous variables; fix binary values first")
        if self.A.shape[0] != 0:
            raise ValueError("BoxQP penalty conversion does not support inequality rows")
        values = {}
        for name, shape in (("Q", (self.nvar, self.nvar)), ("w", (self.nvar,)),
                            ("C", (self.C.shape[0], self.nvar)), ("d", (self.C.shape[0],))):
            value = prepare_float64_coefficient(getattr(self, name), name)
            if value.shape != shape:
                raise ValueError(f"{name} must have shape {shape}")
            data = value.data if sp.sparse.issparse(value) else value
            if not np.all(np.isfinite(data)):
                raise ValueError(f"{name} must contain finite coefficients")
            values[name] = value
        return values['Q'], values['w'], values['C'], values['d']

    @staticmethod
    def _penalty_parameter(value, name):
        value = prepare_float64_coefficient(value, name)
        if value.shape != () or not np.isfinite(value) or value < 0:
            raise ValueError(f"{name} must be a finite nonnegative scalar")
        return float(value)

    def penalty_ratio_helper(self):
        """Return max-entry(Q,w)/max-entry(C,d), or one if C and d vanish.

        This is the scaling for continuous, equality-only penalty conversion.
        Inequality rows and discrete variables are rejected, not relaxed.
        """
        Q, w, C, d = self._penalty_coefficients()
        objective_scale = max(inf_norm(Q), inf_norm(w))
        equality_scale = max(inf_norm(C), inf_norm(d))
        if equality_scale == 0:
            return 1.0
        with np.errstate(over='ignore', under='ignore'):
            ratio = objective_scale / equality_scale
        if not np.isfinite(ratio) or (objective_scale != 0 and ratio == 0):
            raise ValueError("Penalty ratio must be finite and representable in float64")
        return float(ratio)

    def to_BoxQP_with_penalty(self, p):
        """Convert continuous equalities to a finite nonnegative quadratic penalty.

        The returned objective is ``f(x) + .5*p*||C@x-d||^2`` minus the
        constant ``.5*p*(d@d)``, which BoxQP cannot store. A finite penalty
        does not guarantee equality feasibility. Inequality rows are rejected:
        their one-sided squared residual is not a single quadratic form in
        the original variables. Discrete MIQPs must first fix binary values.

        This host float64 transformation prepares coefficients before products,
        retains Q's dense/sparse representation, and copies mutable storage.
        Nonfinite results or lost scaled inputs raise ValueError; remaining
        products and sums follow ordinary float64 rounding.
        """
        p = self._penalty_parameter(p, 'p')
        Q, w, C, d = self._penalty_coefficients()
        if p == 0 or C.shape[0] == 0:
            return BoxQP(copy_mutable_data(Q), copy_mutable_data(w),
                         copy_mutable_data(self.bounds))
        # Scale before forming a Gram matrix: C.T@C can overflow or underflow
        # even when p*(C.T@C) is representable. The same factorization applies
        # to p*C.T@d, without making an intermediate p*d first.
        scale = np.sqrt(p)
        with np.errstate(over='ignore', under='ignore', invalid='ignore'):
            scaled_C, scaled_d = C * scale, d * scale
        for original, scaled in ((C, scaled_C), (d, scaled_d)):
            original_data = original.data if sp.sparse.issparse(original) else original
            data = scaled.data if sp.sparse.issparse(scaled) else scaled
            if not np.all(np.isfinite(data)) or np.any((original_data != 0) & (data == 0)):
                raise ValueError("Scaled penalty coefficients must be finite and representable in float64")
        with np.errstate(over='ignore', under='ignore', invalid='ignore'):
            gram = scaled_C.T @ scaled_C
            if sp.sparse.issparse(Q):
                gram = sp.sparse.csr_matrix(gram)
            elif sp.sparse.issparse(gram):
                gram = gram.toarray()
            Q_prime = Q + gram
            w_prime = w - scaled_C.T @ scaled_d
        for value in (Q_prime, w_prime):
            data = value.data if sp.sparse.issparse(value) else value
            if not np.all(np.isfinite(data)):
                raise ValueError("Penalty objective coefficients must be finite in float64")
        return BoxQP(Q_prime, w_prime, copy_mutable_data(self.bounds))

    def to_BoxQP_with_penalty_ratio(self, pr):
        """Use p=pr*max-entry(Q,w)/max-entry(C,d) for equality penalties.

        ``pr`` must be finite and nonnegative. When C and d both vanish, the
        scale ratio is one. Domain and constant-offset rules match
        ``to_BoxQP_with_penalty``.
        """
        pr = self._penalty_parameter(pr, 'pr')
        if pr == 0:
            return self.to_BoxQP_with_penalty(0.)
        ratio = self.penalty_ratio_helper()
        with np.errstate(over='ignore', under='ignore'):
            p = pr * ratio
        if not np.isfinite(p) or (ratio != 0 and p == 0):
            raise ValueError("Penalty coefficient must be finite and representable in float64")
        return self.to_BoxQP_with_penalty(p)

    def relKKT(self, x, y, z, boundary_eps=1e-6, return_details=False):
        """Normalized continuous KKT residual for supplied multipliers.

        ``y >= 0`` corresponds to ``A @ x <= b``; equality multipliers
        ``z`` are unrestricted. Details are (primal feasibility, projected
        Lagrangian stationarity/dual feasibility, inequality complementarity).
        The third component replaces the legacy algebraic "gap", which was
        invalid for box constraints; it is not an objective-gap certificate.
        ``boundary_eps`` is retained and validated for call compatibility but
        no longer snaps interior points to bounds or suppresses gradients.
        A zero residual is not a global-optimality or integrality certificate.
        """
        if not np.isfinite(boundary_eps) or boundary_eps < 0:
            raise ValueError("boundary_eps must be finite and nonnegative")

        def vector(value, size, name):
            value = prepare_float64_coefficient(value, name, preserve_jax=True)
            if value.shape != (size,):
                raise ValueError(f"{name} must have shape ({size},)")
            return value

        A = prepare_float64_coefficient(self.A, "A", preserve_jax=True)
        C = prepare_float64_coefficient(self.C, "C", preserve_jax=True)
        if A.ndim != 2 or A.shape[1] != self.nvar:
            raise ValueError("A must have shape (n_inequalities, nvar)")
        if C.ndim != 2 or C.shape[1] != self.nvar:
            raise ValueError("C must have shape (n_equalities, nvar)")
        x = vector(x, self.nvar, "x")
        y = vector(y, A.shape[0], "y")
        z = vector(z, C.shape[0], "z")
        b = vector(self.b, A.shape[0], "b")
        d = vector(self.d, C.shape[0], "d")
        lower = vector(self.bounds[0], self.nvar, "lower bounds")
        upper = vector(self.bounds[1], self.nvar, "upper bounds")
        # Invalid numerical inputs are reported as infinite residuals below.
        with np.errstate(over="ignore", invalid="ignore", under="ignore"):
            gradient = self.grad(x)
            Ax, Cx, ATy, CTz = A @ x, C @ x, A.T @ y, C.T @ z
        values = (x, y, z, b, d, lower, upper, gradient, Ax, Cx, ATy, CTz)
        xp = jnp if any(isinstance(v, (jax.Array, jax.core.Tracer))
                        for v in values) else np

        def norm(value):
            return xp.max(xp.abs(value), initial=0.0)

        def scale(*operands):
            result = xp.asarray(1.0)
            for value in operands:
                result = xp.maximum(result, norm(value))
            return result

        # Normalize before subtraction/products to avoid avoidable overflow.
        with np.errstate(over="ignore", invalid="ignore", under="ignore"):
            scale_A, scale_C = scale(Ax, b), scale(Cx, d)
            slack = Ax / scale_A - b / scale_A
            equality = Cx / scale_C - d / scale_C
            scale_box = scale(x, xp.where(xp.isfinite(lower), lower, 0.0),
                              xp.where(xp.isfinite(upper), upper, 0.0))
            r_primal = xp.maximum(norm(xp.maximum(slack, 0.0)), norm(equality))
            r_primal = xp.maximum(r_primal, norm(xp.maximum(
                lower / scale_box - x / scale_box, 0.0)))
            r_primal = xp.maximum(r_primal, norm(xp.maximum(
                x / scale_box - upper / scale_box, 0.0)))

            scale_dual = scale(gradient, ATy, CTz)
            lagrangian = gradient / scale_dual + ATy / scale_dual + CTz / scale_dual
            # clip(g, x-u, x-l) equals x-clip(x-g,l,u), without losing a
            # small gradient when subtracting it from a large coordinate.
            projected = xp.clip(lagrangian, x / scale_dual - upper / scale_dual,
                                x / scale_dual - lower / scale_dual)
            scaled_y = y / scale(y)
            r_dual = xp.maximum(norm(projected), norm(xp.minimum(scaled_y, 0.0)))
            r_complementarity = norm(scaled_y * slack)

        valid = xp.all(lower <= upper) & xp.all(lower < xp.inf) & xp.all(upper > -xp.inf)
        for value in (x, y, z, b, d, gradient, Ax, Cx, ATy, CTz):
            valid = valid & xp.all(xp.isfinite(value))
        details = tuple(xp.where(valid & xp.isfinite(value), value, xp.inf)
                        for value in (r_primal, r_dual, r_complementarity))
        if return_details:
            return details
        return xp.max(xp.stack(details))

    def obj_batch(self, X):
        """Delegate to BoxQP batched objective (supports NumPy and JAX arrays)."""
        # BoxQP implements obj_batch and obj_batch_jax_vmap
        from phisolve.problems.boxqp import BoxQP
        return BoxQP.obj_batch(self, X)

    def max_vios_batch(self, X):
        """Vectorized max-violation per sample for LCQP.

        Accepts X shape (n_samples, nvar). Returns per-sample max violation.
        Supports both NumPy and JAX arrays.
        """
        xp, operands = self._residual_operands(X, linear=True)
        X = xp.atleast_2d(operands["x"])
        X_t = X.T
        vio_ineq = xp.maximum(0.0, operands["A"] @ X_t - operands["b"][:, None])
        vio_eq = operands["C"] @ X_t - operands["d"][:, None]
        vio_lb = xp.maximum(0.0, operands["lower"][:, None] - X_t)
        vio_ub = xp.maximum(0.0, X_t - operands["upper"][:, None])
        vio = xp.concatenate([vio_ineq, xp.abs(vio_eq), vio_lb, vio_ub], axis=0)
        return xp.max(vio, axis=0, initial=0.0)
