import time

import jax
import numpy as np
import scipy as sp
from attr import define, field
from jax import jit, vmap

from phisolve.backends import Backend, QIHD
from phisolve.problems import MIQP, QUBO, Problem
from phisolve.refiners import PDQP, Refiner
from phisolve.response import Response
from phisolve.utils.device_utils import resolve_device
from phisolve.utils.model_validation import validate_qihd_model
from phisolve.utils.precision import prepare_float64_coefficient
from phisolve.validation import as_float64_exact, validate_candidate


@define
class PhiMIQP:
    problem_instance: Problem = field()
    backend: Backend = field(factory=QIHD)
    refiner: Refiner = field(factory=PDQP)
    remove_diagonal: bool = field(default=True)
    compiled_problem_instance: MIQP = field(default=None)
    last_refinement_diagnostics: list = field(factory=list, init=False)

    def __attrs_post_init__(self):
        if not isinstance(self.problem_instance, MIQP):
            kwargs = self.problem_instance.to_dict()
            if isinstance(self.problem_instance, QUBO):
                kwargs["n_binary_vars"] = self.problem_instance.Q.shape[0]
            self.problem_instance = MIQP(**kwargs)

    def compile(self, N, problem=None):
        """Compile the established endpoint-search surrogate without mutation.

        Exactly the first N spin diagonals are removed. Their contribution
        on endpoint spins is the constant 0.5 * sum(diagonal[:N]); final
        reporting always evaluates the full original objective instead.
        """
        problem = self.problem_instance if problem is None else problem
        validate_qihd_model(problem)
        if (isinstance(N, (bool, np.bool_)) or not isinstance(N, (int, np.integer))
                or not 0 <= N <= problem.nvar):
            raise ValueError("N must be an integer between 0 and nvar")
        # Compilation is host arithmetic even when the caller stores the
        # original model in immutable JAX arrays or uses lower device precision.
        problem = self._host_model(problem)
        Q, w = problem.calc_Q_w_affine()
        A, b, C, d = problem.calc_A_b_C_d_affine()
        Q = Q.copy()
        if sp.sparse.issparse(Q):
            diagonal = Q.diagonal().copy()
            diagonal[:N] = 0
            Q.setdiag(diagonal)
            Q.eliminate_zeros()
        else:
            np.fill_diagonal(Q[:N, :N], 0)
        return Q, w, A, b, C, d

    def solve(self, if_refine=True):
        """Solve and report synchronized wall-clock durations in seconds.

        ``time`` and ``detailed_time["Total"]`` cover this call through response
        construction. Phase entries do not overlap; the legacy ``QIHD_Time``
        additionally aggregates ``Backend`` and ``Postprocessing``. Backend
        time includes any JIT compilation and the host materialization of its
        output. ``Validation`` measures final refined-candidate checks and is
        zero when those checks do not run. Later calls to response ``select``,
        ``minimum`` or ``minimizer`` are outside this solve interval.
        """
        solve_start = time.perf_counter()
        # One snapshot per solve, not per trajectory. Response keeps this model
        # so later edits to the caller's model do not reinterpret past results.
        original = self.problem_instance.clone()
        validate_qihd_model(original)
        host = self._host_model(original)
        if isinstance(self.remove_diagonal, (bool, np.bool_)):
            count = original.nvar if self.remove_diagonal else 0
        else:
            count = self.remove_diagonal
        if_refine = bool(if_refine and original.nvar != original.n_binary_vars)
        if if_refine:
            prototype = host.fix_binary_values(host.bounds[0][:host.n_binary_vars])
            self.refiner.validate_problem(prototype)

        Q, w, A, b, C, d = self.compile(count, problem=host)
        # Retain the existing policy: all coordinates use endpoints during the
        # coarse search; continuous coordinates are then refined.
        self.compiled_problem_instance = MIQP(
            Q=Q, w=w, A=A, b=b, C=C, d=d, n_binary_vars=original.nvar
        )
        backend_start = time.perf_counter()
        raw_samples = self.backend.generate_samples(self.compiled_problem_instance)
        # Materializing a JAX result waits for execution and its host transfer,
        # including custom backends that return an asynchronous device array.
        samples = np.asarray(raw_samples)
        backend_end = time.perf_counter()
        if samples.ndim != 2 or samples.shape[1] != original.nvar:
            raise ValueError("backend samples must have shape (n_samples, nvar)")
        if samples.dtype.kind not in "biuf":
            raise ValueError("backend samples must be real numeric values")
        # Decode in host precision without hidden clipping or repair.
        spins = as_float64_exact(raw_samples, "backend samples")
        samples = host.affine_trans(spins)
        # Exact endpoint spins have exact original coordinates, even when the
        # equivalent k * spin + midpoint formula suffers cancellation.
        samples = np.where(spins == 1, host.bounds[0], samples)
        samples = np.where(spins == -1, host.bounds[1], samples)
        samples, sample_counts = np.unique(samples, axis=0, return_counts=True)
        postprocessing_end = time.perf_counter()
        detailed_time = {
            "Preprocessing": backend_start - solve_start,
            "Backend": backend_end - backend_start,
            "Postprocessing": postprocessing_end - backend_end,
            "QIHD_Time": postprocessing_end - backend_start,
            "Validation": 0.0,
        }

        self.last_refinement_diagnostics = []
        if if_refine and len(samples):
            # SciPy sparse matrix products cannot consume JAX tracers during
            # fixed-support reduction. Group supports on the host in that case.
            has_sparse = any(sp.sparse.issparse(matrix) for matrix in (original.Q, original.A, original.C))
            if self.refiner.vmappable and not has_sparse:
                refined, elapsed = self._refine_vmapped(samples, problem=original)
            else:
                refined, elapsed = self._refine_batched(samples, problem=original)
            detailed_time["Refinement"] = elapsed
            # Every refiner is checked against the original model, including
            # refiners that cannot provide optimizer convergence diagnostics.
            validation_start = time.perf_counter()
            final = []
            for index, candidate in enumerate(refined):
                validation = validate_candidate(original, candidate)
                self.last_refinement_diagnostics[index]["original_validation"] = validation
                final.append(candidate if validation.valid else None)
            if all(candidate is not None for candidate in final):
                final = np.asarray(final)
            detailed_time["Validation"] = time.perf_counter() - validation_start
            response_start = time.perf_counter()
            response = Response(
                original, samples, sample_counts, final, detailed_time=detailed_time,
                refinement_diagnostics=self.last_refinement_diagnostics,
            )
        else:
            response_start = time.perf_counter()
            response = Response(original, samples, sample_counts, detailed_time=detailed_time)
        response_end = time.perf_counter()
        detailed_time["Response_Construction"] = response_end - response_start
        response.time = response_end - solve_start
        detailed_time["Total"] = response.time
        return response

    @staticmethod
    def _can_refine(problem, sample):
        validation = validate_candidate(problem, sample)
        # A refiner may repair linear constraints and continuous bounds, but
        # cannot fix a missing/nonfinite/fractional binary assignment as support.
        return (np.all(np.isfinite(sample))
                and validation.max_binary_violation <= 1e-5)

    def _refine_batched(self, samples, problem=None):
        start = time.perf_counter()
        problem = self.problem_instance if problem is None else problem
        problem = self._host_model(problem)
        n_bin = problem.n_binary_vars
        refined = [None] * len(samples)
        diagnostics = [{"success": None, "message": "invalid coarse assignment"}
                       for _ in samples]
        groups = {}
        for index, sample in enumerate(samples):
            if self._can_refine(problem, sample):
                groups.setdefault(tuple(sample[:n_bin]), []).append(index)
        for binary_values, indices in groups.items():
            reduced = problem.fix_binary_values(np.asarray(binary_values))
            values = self.refiner.refine(samples=np.asarray(samples)[indices, n_bin:], problem=reduced)
            if len(values) != len(indices):
                raise ValueError("refiner must return one entry per input sample")
            reports = getattr(self.refiner, "last_diagnostics", None)
            if reports is not None and len(reports) != len(indices):
                raise ValueError("refiner diagnostics must align with samples")
            for offset, index in enumerate(indices):
                diagnostics[index] = dict(reports[offset]) if reports is not None else {"success": None}
                value = values[offset]
                if value is not None:
                    # Check the raw result before array promotion or binary
                    # reconstruction can round an invalid integer coordinate.
                    try:
                        value = as_float64_exact(value, "refiner candidate")
                    except ValueError as error:
                        diagnostics[index]["candidate_error"] = str(error)
                        diagnostics[index].setdefault("message", str(error))
                        continue
                    if value.shape != (problem.nvar - n_bin,):
                        diagnostics[index]["message"] = "invalid refiner candidate shape"
                    else:
                        refined[index] = np.concatenate((np.asarray(binary_values), value))
        self.last_refinement_diagnostics = diagnostics
        return refined, time.perf_counter() - start

    @staticmethod
    def _host_model(problem):
        """Prepare host coefficients for compilation, decoding, and reduction.

        Conversion is independent of the refiner's execution precision. Already
        float64 arrays may be shared here; reduction copies mutable subblocks.
        """
        kwargs = problem.to_dict()
        for name in ("Q", "w", "A", "b", "C", "d"):
            kwargs[name] = prepare_float64_coefficient(kwargs[name], name)
        kwargs["bounds"] = tuple(as_float64_exact(bound, "bounds")
                                 for bound in kwargs["bounds"])
        return MIQP(**kwargs)

    def _refine_vmapped(self, samples, problem=None):
        start = time.perf_counter()
        problem = self.problem_instance if problem is None else problem
        problem = self._host_model(problem)
        n_bin = problem.n_binary_vars
        refined = [None] * len(samples)
        diagnostics = [{"success": None, "message": "invalid coarse assignment"}
                       for _ in samples]
        groups = {}
        for index, sample in enumerate(samples):
            if self._can_refine(problem, sample):
                groups.setdefault(tuple(sample[:n_bin]), []).append(index)

        for binary_values, indices in groups.items():
            # Substitute exact host endpoints before any JAX dtype conversion.
            # Only continuous starting points enter the vmapped execution.
            reduced = problem.fix_binary_values(np.asarray(binary_values))

            def refine_one(continuous):
                value = self.refiner.refine(samples=continuous[None, :], problem=reduced)
                return value[0]

            missing = object()
            previous = getattr(self.refiner, "problem", missing)
            pending_error = None
            try:
                target = resolve_device(getattr(self.refiner, "device", "cpu"))
                initial = jax.device_put(np.asarray(samples)[indices, n_bin:], target)
                with jax.default_device(target):
                    values = jit(vmap(refine_one))(initial)
                if not isinstance(values, (jax.Array, np.ndarray)):
                    raise ValueError("vmapped refiner must return a single candidate array")
                # Include device completion and host transfer in the timer.
                values = np.asarray(jax.device_get(values))
            except BaseException as refinement_error:
                # Track this call's failure, not an exception the caller may
                # already be handling when it invokes solve(). Always re-raise.
                pending_error = refinement_error
                raise
            finally:
                # Pure/immutable custom refiners need no writes. Restore only
                # scratch state changed by this call, preserving its old value.
                # A cleanup failure must not mask the original refiner error.
                try:
                    if getattr(self.refiner, "problem", missing) is not previous:
                        if previous is missing:
                            del self.refiner.problem
                        else:
                            self.refiner.problem = previous
                except Exception as cleanup_error:
                    if pending_error is None:
                        raise
                    if hasattr(pending_error, "add_note"):
                        pending_error.add_note(
                            f"Refiner cleanup failed: {type(cleanup_error).__name__}: {cleanup_error}"
                        )
            if values.shape != (len(indices), problem.nvar - n_bin):
                raise ValueError("vmapped refiner returned an invalid candidate shape")
            for index, value in zip(indices, values):
                diagnostics[index] = {"success": None}
                try:
                    value = as_float64_exact(value, "refiner candidate")
                except ValueError as error:
                    diagnostics[index]["candidate_error"] = str(error)
                    diagnostics[index].setdefault("message", str(error))
                    continue
                # Preserve the original host endpoints exactly, including
                # endpoints that cannot be represented by the refiner's dtype.
                refined[index] = np.concatenate((samples[index, :n_bin], value))
        self.last_refinement_diagnostics = diagnostics
        return refined, time.perf_counter() - start
