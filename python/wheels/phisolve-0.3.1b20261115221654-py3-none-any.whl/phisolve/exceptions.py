"""Narrow backend failures exposed to language adapters.

The base classes preserve compatibility with existing Python callers.  Adapters
must not infer mathematical infeasibility from generic ValueError exceptions.
"""


class QIHDNumericalError(ValueError):
    """Model arithmetic cannot be represented safely in execution precision."""


class QIHDUnsupportedModelError(NotImplementedError):
    """A valid model needs a formulation that QIHD does not implement."""
