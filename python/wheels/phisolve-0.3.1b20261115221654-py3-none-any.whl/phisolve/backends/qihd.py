import logging
from functools import lru_cache
from jax.nn import relu
import jax
from attr import define, field, asdict
import numpy as np
import jax.numpy as jnp
import scipy as sp
from jax import vmap, grad
from phisolve.utils.jax_utils import sp_sparse_mat_to_jsp_BCSR, max_abs_entry, spcomp_matvec
from phisolve.utils.device_utils import resolve_device
from phisolve.utils.model_validation import positive_integer, validate_qihd_model
from phisolve.utils.precision import prepare_float64_coefficient
from phisolve.exceptions import QIHDNumericalError, QIHDUnsupportedModelError

from phisolve.backends.backend import Backend
from phisolve.utils.integrator import Integrator
from phisolve.problems.problem import Problem

_logger = logging.getLogger(__name__)


@lru_cache(maxsize=8)
def _step_function(ballistic, si, constant_cons):
    """Stable dynamics for the eight algorithm modes; model data stays dynamic."""
    def sb_step(parameters, carry, a):
        Q, w, A, b, C, d, I, J, a0, dt, c0, A_pen, C_pen = parameters

        def x_tilde(x):
            return I * jnp.sign(x) + J * x

        def sb_step_one_sample(x, y):
            def V_binary_pen(x):
                binary_x = I * x
                return 0.5 * (a0 - a) * jnp.sum(binary_x**2)

            def V_ineq_con(x):
                Ax_minus_b = spcomp_matvec(A, x) - b
                if constant_cons:
                    return A_pen * jnp.sum(relu(Ax_minus_b))
                return a * A_pen * jnp.sum(relu(Ax_minus_b))

            def V_eq_con(x):
                Cx_minus_d = spcomp_matvec(C, x) - d
                if constant_cons:
                    return C_pen * jnp.sum(jnp.abs(Cx_minus_d))
                return a * C_pen * jnp.sum(jnp.abs(Cx_minus_d))

            def V_f(x):
                fx = 0.5 * x @ spcomp_matvec(Q, x) + w @ x
                return c0 * fx

            @jax.custom_gradient
            def V_f_disc(x):
                fx = 0.5 * x @ spcomp_matvec(Q, x) + w @ x
                return c0 * fx, lambda g: g * c0 * (spcomp_matvec(Q, x_tilde(x)) + w)

            y -= dt * grad(V_binary_pen)(x)
            if not si:
                x += dt * a0 * y

            if ballistic:
                y -= dt * (grad(V_f)(x) + grad(V_ineq_con)(x) + grad(V_eq_con)(x))
            else:
                y -= dt * (grad(V_f_disc)(x) + grad(V_ineq_con)(x_tilde(x)) + grad(V_eq_con)(x_tilde(x)))

            if si:
                x += dt * a0 * y
            # Clipping must not disguise a numerical overflow as an
            # otherwise valid endpoint trajectory.
            finite = jnp.isfinite(x) & jnp.isfinite(y)
            y = jnp.where(finite, jnp.where(jnp.abs(x) > 1.0, 0.0, y), jnp.nan)
            x = jnp.where(finite, jnp.clip(x, -1.0, 1.0), jnp.nan)
            return x, y

        xs, ys = carry
        return vmap(vmap(sb_step_one_sample))(xs, ys)

    return sb_step


@jax.jit
def _finite_state(state):
    """Reduce both trajectory arrays on the execution device before decoding."""
    x, y = state
    return jnp.all(jnp.isfinite(x)) & jnp.all(jnp.isfinite(y))


def _validate_execution_values(value, name, dtype, allow_zero=True):
    """Reject nonfinite, lost, and subnormal execution values on the host.

    XLA may flush subnormals to zero during arithmetic even when NumPy can
    store them. Reject them explicitly instead of silently changing a force
    coefficient or integration parameter. No coefficients are rescaled here.
    """
    data = np.asarray(value)
    with np.errstate(over="ignore", invalid="ignore", under="ignore"):
        cast = data.astype(dtype, copy=False)
        too_small = (data != 0) & (np.abs(cast) < np.finfo(dtype).tiny)
    if (
        not np.all(np.isfinite(cast))
        or np.any(too_small)
        or (not allow_zero and np.any(cast == 0))
    ):
        raise QIHDNumericalError(
            f"{name} cannot be represented as normal finite values in "
            "QIHD's execution precision"
        )
    return cast


@define
class QIHD(Backend):
    """
    Backend instantiation for QIHD.
    """
    n_shots: int = field(default=100)
    n_steps: int = field(default=10000)
    ballistic: bool = field(default=False)
    verbose: bool = field(default=False)
    device: str = field(default="cpu")
    seed: int = field(default=None)
    dt: float = field(default=0.2)
    a0: float = field(default=1.0)
    symplectic_integration: bool = field(default=True)
    slow_a: bool = field(default=True)
    lc_pr: float = field(default=3)   # Penalty ratio of linear constraint
    constant_cons: bool = field(default=False)
    c0_multiplier: float = field(default=0.5)
    execution_device: str = field(default=None, init=False)

    def build_schedule(self):
        """Legacy slow ramp is defined only for n_steps > 1000."""
        steps = positive_integer(self.n_steps, "n_steps")
        if not np.isfinite(self.a0) or self.a0 <= 0:
            raise ValueError("a0 must be finite and positive")
        dtype = np.float64 if jax.config.x64_enabled else np.float32
        _validate_execution_values(self.a0, "a0", dtype, allow_zero=False)
        if self.slow_a and steps <= 1000:
            raise ValueError("slow_a=True requires n_steps > 1000; use slow_a=False for shorter runs")
        denominator = steps - 1000 if self.slow_a else 1000
        schedule = np.minimum(np.arange(steps, dtype=dtype) / denominator, dtype(self.a0))
        _validate_execution_values(schedule, "schedule", dtype)
        return schedule

    @staticmethod
    def decode_spins(x, n_binary_vars):
        """Decode final binary spins; a zero tie selects spin +1.

        The internal force still uses sign(0)=0. Only final decoding uses
        this endpoint rule; the affine map sends +1 to the lower endpoint.
        """
        binary = x[..., :n_binary_vars]
        endpoints = jnp.where(binary >= 0, 1.0, -1.0)
        return x.at[..., :n_binary_vars].set(jnp.where(jnp.isfinite(binary), endpoints, binary))
    
    def c0_default(self, Q, w, A, b, C, d):
        values = tuple(prepare_float64_coefficient(value) for value in (Q, w, A, b, C, d))
        return self._c0_from_prepared(values)

    def _c0_from_prepared(self, values):
        Q, w, A, b, C, d = values
        n_dim = w.shape[0]
        magnitude = max(float(max_abs_entry(value)) for value in values)
        if magnitude == 0:
            # Only the exactly zero model has no objective force to scale.
            return 0.0
        if not np.isfinite(magnitude):
            raise QIHDNumericalError("Model scale must be finite")
        normalized_sum = 0.0
        for value in values:
            if sp.sparse.issparse(value):
                canonical = value.tocsr(copy=True)
                canonical.sum_duplicates()
                value = canonical.data
            normalized = np.asarray(value, dtype=np.float64) / magnitude
            normalized_sum += np.sum(normalized * normalized, dtype=np.float64)
        num_cnt = (n_dim + A.shape[0] + C.shape[0]) * (n_dim + 1)
        normalized_scale = np.sqrt(normalized_sum / num_cnt)
        value = (self.c0_multiplier / (normalized_scale * np.sqrt(n_dim))) / magnitude
        if not np.isfinite(value) or value <= 0:
            raise QIHDNumericalError("Model scale cannot be represented safely by QIHD")
        return value

    def round_to_nearest_device_count(self, n_shots, device_count):
        """Compatibility helper: single-device execution preserves all shots."""
        positive_integer(device_count, "device_count")
        return positive_integer(n_shots, "n_shots")

    def generate_samples(
        self,
        # params: BackendParams,
        problem: Problem,
    ):
        _logger.debug(
            "Generating samples with %s based on %s",
            self.__class__.__name__,
            asdict(self),
        )
        n_shots = positive_integer(self.n_shots, "n_shots")
        validate_qihd_model(problem)
        execution_dtype = np.float64 if jax.config.x64_enabled else np.float32
        for name in ("dt", "c0_multiplier", "lc_pr", "a0"):
            value = getattr(self, name)
            if not np.isfinite(value) or value <= 0:
                raise ValueError(f"{name} must be finite and positive")
            _validate_execution_values(value, name, execution_dtype, allow_zero=False)
        target = resolve_device(self.device)
        a_schedule = self.build_schedule()
        self.execution_device = None
        self.problem = problem
        # Explicitly use one device. No logical trajectories are rounded away.
        n_devices = 1
        ballistic = self.ballistic
        a0 = execution_dtype(self.a0)
        dt = execution_dtype(self.dt)
        si = self.symplectic_integration
        constant_cons = self.constant_cons

        Q, w, A, b, C, d = (
            prepare_float64_coefficient(value)
            for value in (problem.Q, problem.w, problem.A, problem.b, problem.C, problem.d)
        )
        n_dim = w.shape[0]
        n_binary_vars = problem.n_binary_vars
        execution_coefficients = []
        for name, value in zip(("Q", "w", "A", "b", "C", "d"), (Q, w, A, b, C, d)):
            if sp.sparse.issparse(value):
                execution_value = value.copy()
                execution_value.data = _validate_execution_values(value.data, name, execution_dtype)
            else:
                execution_value = _validate_execution_values(value, name, execution_dtype)
            execution_coefficients.append(execution_value)
        def norm(value):
            return float(max_abs_entry(value))
        Q_norm, w_norm = norm(Q), norm(w)
        if max(Q_norm, w_norm) == 0:
            if norm(A) > 0 or norm(C) > 0:
                raise QIHDUnsupportedModelError(
                    "Constraint-only QIHD requires a separately defined feasibility penalty; "
                    "the legacy objective-based penalty scale is zero"
                )
            if np.any(b < 0) or np.any(d != 0):
                raise ValueError("Zero-model constant linear constraints are infeasible")
            trivial = jax.device_put(np.zeros((n_shots, n_dim), dtype=execution_dtype), target)
            trivial = self.decode_spins(trivial, n_binary_vars)
            self.execution_device = str(next(iter(trivial.devices())))
            return np.asarray(jax.device_get(trivial))
        c0 = self._c0_from_prepared((Q, w, A, b, C, d))

        A_norm, b_norm, A_pen = norm(A), norm(b), 1.
        if A_norm > 0 or b_norm > 0:
            A_pen = self.lc_pr * np.max((Q_norm, w_norm)) / np.max((A_norm, b_norm))
        C_norm, d_norm, C_pen = norm(C), norm(d), 1.
        if C_norm > 0 or d_norm > 0:
            C_pen = self.lc_pr * np.max((Q_norm, w_norm)) / np.max((C_norm, d_norm))

        for name, value in (("c0", c0), ("A_pen", A_pen), ("C_pen", C_pen)):
            _validate_execution_values(value, name, execution_dtype, allow_zero=False)
        c0, A_pen, C_pen = (execution_dtype(value) for value in (c0, A_pen, C_pen))

        # Place the actual checked floating arrays, rather than integer source
        # arrays that JAX can narrow to int32 when x64 is disabled.
        Q, w, A, b, C, d = execution_coefficients
        if sp.sparse.issparse(Q):
            Q = sp_sparse_mat_to_jsp_BCSR(Q)
        if sp.sparse.issparse(A):
            A = sp_sparse_mat_to_jsp_BCSR(A)
        if sp.sparse.issparse(C):
            C = sp_sparse_mat_to_jsp_BCSR(C)
        Q, w, A, b, C, d = jax.device_put((Q, w, A, b, C, d), target)

        I = jnp.zeros(n_dim)
        I = I.at[:n_binary_vars].set(1)
        I = jax.device_put(I, target)
        J = 1 - I

        sb_step = Integrator.reusable(
            _step_function(bool(ballistic), bool(si), bool(constant_cons)),
            (Q, w, A, b, C, d, I, J, a0, dt, c0, A_pen, C_pen),
        )

        a_schedule = jax.device_put(a_schedule, target)
        if self.seed is not None:
            rng = np.random.default_rng(seed=self.seed)
        else:
            rng = np.random.default_rng()
        array = 2 * rng.random((2, n_devices, int(n_shots / n_devices), n_dim)) - 1
        x = jax.device_put(array[0].astype(execution_dtype), target)
        y = jax.device_put(array[1].astype(execution_dtype), target)
        result = Integrator.integrate(sb_step, (x, y), a_schedule, device=target)
        x_final = result[0]
        if not bool(jax.device_get(_finite_state(result))):
            raise FloatingPointError("QIHD produced a nonfinite trajectory")
        x_final = self.decode_spins(x_final, n_binary_vars)
        self.execution_device = str(next(iter(x_final.devices())))
        x_final = jax.device_get(x_final)
        x_final = x_final.reshape(n_shots, n_dim)
        if not np.all(np.isfinite(x_final)):
            raise FloatingPointError("QIHD produced nonfinite candidates")
        return x_final
